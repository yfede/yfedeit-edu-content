
USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030712' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T030712')
begin
  DROP DATABASE T030712
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030712' il proprio numero di tessera o matricola

CREATE DATABASE T030712
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030712' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T030712
GO

-- NON MODIFICARE NULLA NEL RESTO DI QUESTO FILE
-- SE NON ISTRUITO IN PROPOSITO DAL DOCENTE

CREATE TABLE libro
	(
	codISBN		char(20) NOT NULL PRIMARY KEY CLUSTERED,
	titolo		varchar(40) NOT NULL,
	categoria 	varchar(20) NOT NULL,
	pagine		int NULL,
	prezzo	 	money NULL
	)
GO

CREATE TABLE cliente
	(
	codCliente	char(12) NOT NULL PRIMARY KEY CLUSTERED,
	cognome	 	varchar(40) NOT NULL,
	nome		varchar(30) NOT NULL,
	nazionalita	varchar(20) NULL,
	eta 		char(12) NULL
	)
GO

CREATE TABLE acquisto
	(
	codLibro 	char(20) NOT NULL,
	codCliente	char(12) NOT NULL,
	data 		datetime NOT NULL
	)
GO

CREATE TABLE scaffale
	(
	codScaffale	char(11) NOT NULL PRIMARY KEY CLUSTERED,
	descrizione 	varchar(40) NOT NULL,
	posizione	char(10) NOT NULL
	)
GO

CREATE TABLE scaffale_libro
	(
	codScaffale	char(11) NOT NULL,
	codLibro 	char(20) NOT NULL
	)
GO

-- FINE CREAZIONE STRUTTURA

-- INIZIO CARICAMENTO DATI

set nocount    on
set dateformat dmy
GO

INSERT INTO libro VALUES('88-371-1090-1','Progetto di Basi di Dati Relazionali','computer',240,16.50)
INSERT INTO libro VALUES('88-371-1090-2','Inside SQL server 2000','computer',1047,67.14)
INSERT INTO libro VALUES('88-371-1090-3','The Cunningham equations','fantascienza',150,8.90)
INSERT INTO libro VALUES('88-371-1090-4','Timescape','fantascienza',210,9.50)
GO

INSERT INTO cliente VALUES('1000','Bennet','Abraham','USA',41)
INSERT INTO cliente VALUES('1001','Green','Marjorie','USA',30)
INSERT INTO cliente VALUES('1002','Carson','Cheryl','USA',18)
INSERT INTO cliente VALUES('1003','DeFrance','Michel','USA',75)
INSERT INTO cliente VALUES('1004','MacFeather','Stearns','USA',16)
INSERT INTO cliente VALUES('1005','Yokomoto','Akiko','Japan',28)
GO

INSERT INTO acquisto VALUES('88-371-1090-1','1000','18/01/2002')
INSERT INTO acquisto VALUES('88-371-1090-1','1001','18/01/2002')
INSERT INTO acquisto VALUES('88-371-1090-1','1002','18/02/2002')
INSERT INTO acquisto VALUES('88-371-1090-1','1004','18/03/2002')
INSERT INTO acquisto VALUES('88-371-1090-1','1005','18/03/2002')
INSERT INTO acquisto VALUES('88-371-1090-1','1005','18/12/2002')
INSERT INTO acquisto VALUES('88-371-1090-2','1000','18/04/2002')
INSERT INTO acquisto VALUES('88-371-1090-2','1001','18/05/2002')
INSERT INTO acquisto VALUES('88-371-1090-2','1002','18/05/2002')
INSERT INTO acquisto VALUES('88-371-1090-2','1003','18/05/2002')
INSERT INTO acquisto VALUES('88-371-1090-2','1005','18/09/2002')
INSERT INTO acquisto VALUES('88-371-1090-3','1000','18/09/2002')
INSERT INTO acquisto VALUES('88-371-1090-3','1001','18/11/2002')
INSERT INTO acquisto VALUES('88-371-1090-3','1002','18/04/2002')
INSERT INTO acquisto VALUES('88-371-1090-3','1003','18/05/2002')
INSERT INTO acquisto VALUES('88-371-1090-3','1005','18/07/2002')
INSERT INTO acquisto VALUES('88-371-1090-4','1000','18/08/2002')
INSERT INTO acquisto VALUES('88-371-1090-4','1001','18/09/2002')
INSERT INTO acquisto VALUES('88-371-1090-4','1002','18/10/2002')
GO

INSERT INTO scaffale VALUES('AA01','Area Tecnologia','AA01')
INSERT INTO scaffale VALUES('BA01','Area Fantascienza','BA01')
GO

INSERT INTO scaffale_libro VALUES('AA01','88-371-1090-1')
INSERT INTO scaffale_libro VALUES('AA01','88-371-1090-2')
INSERT INTO scaffale_libro VALUES('BA01','88-371-1090-3')
INSERT INTO scaffale_libro VALUES('BA01','88-371-1090-4')
GO

-- FINE CARICAMENTO DATI

-- FINE FILE