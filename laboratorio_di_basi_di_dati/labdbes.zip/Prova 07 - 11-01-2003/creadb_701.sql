
USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030111' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T030111')
begin
  DROP DATABASE T030111
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030111' il proprio numero di tessera o matricola

CREATE DATABASE T030111
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '030111' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T030111
GO

-- NON MODIFICARE NULLA NEL RESTO DI QUESTO FILE
-- SE NON ISTRUITO IN PROPOSITO DAL DOCENTE

CREATE TABLE Publisher
	(
	PublisherCode	char(20) NOT NULL PRIMARY KEY CLUSTERED,
	TradeName	varchar(40) NOT NULL,
	Address 	varchar(120) NULL
	)
GO

CREATE TABLE Author
	(
	AuthorCode	char(12) NOT NULL PRIMARY KEY CLUSTERED,
	LastName 	varchar(40) NOT NULL,
	FirstName	varchar(30) NOT NULL,
	DateOfBirth	datetime NULL,
	DateOfDeath	datetime NULL,
	Address 	varchar(120) NULL,
	HomePageURL 	varchar(180) NULL
	)
GO

CREATE TABLE Publication
	(
	PublicationCode	char(12) NOT NULL PRIMARY KEY CLUSTERED,
	Title		varchar(180) NOT NULL,
	Type		varchar(20) NOT NULL,
	PubYear 	integer NOT NULL,
	ISBN		char(40) NULL,
	ISSN		char(40) NULL,
	LCCN		char(40) NULL,
	PublisherCode	char(20) NOT NULL,
	)
GO

CREATE TABLE PubItem
	(
	PubItemCode	char(12) NOT NULL PRIMARY KEY CLUSTERED,
	Title	 	varchar(180) NOT NULL,
	Chapter		integer NULL,
	Abstract	varchar(3000) NULL,
	Copyright	varchar(120) NULL,
	Language	char(2) NOT NULL,
	PublicationCode	char(12) NOT NULL
		REFERENCES Publication(PublicationCode)
	)
GO

CREATE TABLE ReferenceTable
	(
	RefCode			char(12) NOT NULL PRIMARY KEY CLUSTERED,
	ItemCode 		char(12) NOT NULL,
	ReferencesItemCode	char(12) NOT NULL
	)
GO

CREATE TABLE AutPub
	(
	AuthorCode	char(12),
	PubItemCode	char(12)
	)
GO

-- FINE CREAZIONE STRUTTURA

-- INIZIO CARICAMENTO DATI

set nocount    on
set dateformat dmy
GO

INSERT INTO Publisher(PublisherCode,TradeName) VALUES ('E0000001','Editore1')
INSERT INTO Publisher(PublisherCode,TradeName) VALUES ('E0000002','Editore2')
INSERT INTO Publisher(PublisherCode,TradeName) VALUES ('E0000003','Editore3')
INSERT INTO Publisher(PublisherCode,TradeName) VALUES ('E0000004','Editore4')
INSERT INTO Publisher(PublisherCode,TradeName) VALUES ('E0000005','Editore5')

INSERT INTO Author(AuthorCode,LastName,FirstName) VALUES ('A000001','Cognome1','Nome1')
INSERT INTO Author(AuthorCode,LastName,FirstName) VALUES ('A000002','Cognome2','Nome2')
INSERT INTO Author(AuthorCode,LastName,FirstName) VALUES ('A000003','Cognome3','Nome3')
INSERT INTO Author(AuthorCode,LastName,FirstName) VALUES ('A000004','Cognome4','Nome4')
INSERT INTO Author(AuthorCode,LastName,FirstName) VALUES ('A000005','Cognome5','Nome5')

INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000001','Pubblicazione 1','Rivista',2001,NULL,1,NULL,'E0000001')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000002','Pubblicazione 2','Rivista',2002,NULL,1,NULL,'E0000002')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000003','Pubblicazione 3','Rivista',2003,NULL,1,NULL,'E0000003')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000004','Libro 1','Libro',2001,1,NULL,NULL,'E0000002')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000005','Libro 2','Libro',2002,2,NULL,NULL,'E0000004')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000006','Libro 3','Libro',2003,3,NULL,NULL,'E0000004')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000007','Note 1','Conferenza',2001,1,NULL,NULL,'E0000002')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000008','Note 2','Conferenza',2002,2,NULL,NULL,'E0000004')
INSERT INTO Publication(PublicationCode,Title,Type,PubYear,ISBN,ISSN,LCCN,PublisherCode) VALUES ('P000009','Note 3','Conferenza',2002,2,NULL,NULL,'E0000005')

INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00010001','Titolo item 11','IT','P000001')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00010002','Titolo item 12','IT','P000001')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00010003','Titolo item 13','IT','P000001')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00010004','Titolo item 14','IT','P000001')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00020001','Titolo item 21','IT','P000002')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00020002','Titolo item 22','IT','P000002')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00020003','Titolo item 23','IT','P000002')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00020004','Titolo item 24','IT','P000002')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00020005','Titolo item 25','IT','P000002')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030001','Titolo item 31','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030002','Titolo item 32','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030003','Titolo item 33','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030004','Titolo item 34','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030005','Titolo item 35','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030006','Titolo item 36','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00030007','Titolo item 37','IT','P000003')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00040001','Libro 1','IT','P000004')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00050001','Libro 2','IT','P000005')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00060001','Libro 3','IT','P000006')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00070001','Note 1','IT','P000007')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00080001','Note 2','IT','P000008')
INSERT INTO PubItem(PubItemCode,Title,Language,PublicationCode) VALUES 
('I00090001','Note 3','IT','P000009')

INSERT INTO  ReferenceTable VALUES ('R0000001','I00010001','I00010002')
INSERT INTO  ReferenceTable VALUES ('R0000002','I00010001','I00010003')
INSERT INTO  ReferenceTable VALUES ('R0000003','I00010002','I00030001')
INSERT INTO  ReferenceTable VALUES ('R0000004','I00010002','I00030003')
INSERT INTO  ReferenceTable VALUES ('R0000005','I00010002','I00020004')
INSERT INTO  ReferenceTable VALUES ('R0000006','I00010002','I00020005')
INSERT INTO  ReferenceTable VALUES ('R0000007','I00010003','I00030001')
INSERT INTO  ReferenceTable VALUES ('R0000008','I00010003','I00030002')
INSERT INTO  ReferenceTable VALUES ('R0000009','I00010003','I00030004')
INSERT INTO  ReferenceTable VALUES ('R0000010','I00010003','I00050001')

INSERT INTO  AutPub VALUES ('A000001','I00010001')
INSERT INTO  AutPub VALUES ('A000002','I00010001')
INSERT INTO  AutPub VALUES ('A000003','I00010002')
INSERT INTO  AutPub VALUES ('A000001','I00010003')
INSERT INTO  AutPub VALUES ('A000004','I00010002')
INSERT INTO  AutPub VALUES ('A000004','I00010004')
INSERT INTO  AutPub VALUES ('A000003','I00020001')
INSERT INTO  AutPub VALUES ('A000004','I00020001')
INSERT INTO  AutPub VALUES ('A000001','I00020002')
INSERT INTO  AutPub VALUES ('A000001','I00020003')
INSERT INTO  AutPub VALUES ('A000002','I00020004')
INSERT INTO  AutPub VALUES ('A000002','I00020005')
INSERT INTO  AutPub VALUES ('A000001','I00030001')
INSERT INTO  AutPub VALUES ('A000001','I00030002')
INSERT INTO  AutPub VALUES ('A000001','I00030003')
INSERT INTO  AutPub VALUES ('A000002','I00030004')
INSERT INTO  AutPub VALUES ('A000002','I00030005')
GO

-- FINE CARICAMENTO DATI

-- FINE FILE