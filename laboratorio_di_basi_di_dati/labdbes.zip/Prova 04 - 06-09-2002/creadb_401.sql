set nocount    on
set dateformat mdy

USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo
-- a '12345' il proprio numero di matricola (due modifiche)

if exists (select * from sysdatabases where name='T020906')
begin
  drop database T020906
end
GO

-- nel comando che segue cambiare il nome del database sostituendo
-- a '12345' il proprio numero di matricola

CREATE DATABASE T020906
GO

-- nel comando che segue cambiare il nome del database sostituendo
-- a '12345' il proprio numero di matricola

USE T020906
GO 

CREATE TABLE autore
(
   au_cf          varchar(11)       NOT NULL
         CONSTRAINT UPKCL_auidind PRIMARY KEY CLUSTERED,
   au_nome        varchar(40)        NOT NULL,
   data_nascita	  datetime   NOT NULL,
   data_decesso   datetime
)
GO

CREATE TABLE pubblicazione
(
   title_id       varchar(6)        NOT NULL
         CONSTRAINT UPKCL_titleidind PRIMARY KEY CLUSTERED,
   title          varchar(80)       NOT NULL,
   type           varchar(12)          NOT NULL
         DEFAULT ('da definire'),
   pubdate        datetime          NOT NULL
         DEFAULT (getdate())
)
GO

CREATE TABLE libro
(
   title_id       varchar(6)        NOT NULL
         REFERENCES pubblicazione(title_id),
   isbn 	  varchar(13) 	    NOT NULL UNIQUE,
   CONSTRAINT UPKCL_libroind PRIMARY KEY CLUSTERED (title_id)
)
GO

CREATE TABLE articolo
(
   title_id       varchar(6)        NOT NULL
         REFERENCES pubblicazione(title_id),
   rivista 	  varchar(20) 	    NOT NULL,
   volume         int       NOT NULL,
   numero         int       NOT NULL
)
GO

CREATE TABLE autoripubblicazione
(
   au_cf          varchar(11)       NOT NULL
         REFERENCES autore(au_cf),
   title_id       varchar(6)        NOT NULL
         REFERENCES pubblicazione(title_id),
   CONSTRAINT UPKCL_apind PRIMARY KEY CLUSTERED(au_cf, title_id)
)
GO

CREATE TABLE pubcitazione
(
   pub_citante       varchar(6)        NOT NULL
         REFERENCES pubblicazione(title_id),
   pub_citato       varchar(6)        NOT NULL
         REFERENCES pubblicazione(title_id),
   CONSTRAINT UPKCL_pubcitazione PRIMARY KEY CLUSTERED (pub_citante,pub_citato)
)
GO

-- inizio dati
insert autore values('KKKJJJC456F','Karin Jokovich','04/30/1950',null)
insert autore values('FFFMMMD345H','Frederich Meyer','08/12/1901','05/23/1986')
insert autore values('AAAYYYR456N','Alec Yashin','09/15/1934',null)
insert autore values('JJJMMMA456S','Johann Moser','03/05/1923','02/22/1995')
insert autore values('AAABBBI456A','Alessandro Brini','07/04/1972',null)
insert autore values('YYYDDDF456Y','Yves Duval','11/30/1950',null)
insert autore values('SSSVVVS456L','Sergio Vega','12/27/1960',null)
insert autore values('SSSSSSN456D','Stefan Svensson','10/14/1945','12/12/1992')
insert autore values('SSSMMMG456B','Steve Miller','01/28/1942','04/14/1998')
GO

insert pubblicazione values ('PB0001','I campi magnetici','Fisica','02/14/1995')
insert pubblicazione values ('PB0002','Le comete','Astronomia','11/23/1998')
insert pubblicazione values ('PB0003','I vulcani','Geologia','03/24/1951')
insert pubblicazione values ('PB0004','I moti relativi','Fisica','10/05/1990')
insert pubblicazione values ('PB0005','Vita nella Foresta Nera','Biologia','08/15/2002')
insert pubblicazione values ('PB0006','Esperimenti sui quanti','Fisica','04/02/1997')
insert pubblicazione values ('PB0007','Marte e Venere','Astronomia','02/14/1995')
insert pubblicazione values ('PB0008','Climi e venti mitteleuropei','Geologia','03/12/2000')
insert pubblicazione values ('PB0009','Considerazioni sul magnetismo','Fisica','04/27/1993')
insert pubblicazione values ('PB0010','Tecnologia aerospaziale: lo Shuttle','Aeronautica','09/11/1980')
insert pubblicazione values ('PB0011','Analisi chimica delle acque dolomitiche','Geologia','08/14/1930')
GO

insert libro values('PB0001','87-7303-692-9')
insert libro values('PB0002','78-2341-692-8')
insert libro values('PB0003','44-7303-132-3')
insert libro values('PB0004','23-1475-583-9')
insert libro values('PB0005','64-9934-154-4')
insert libro values('PB0007','24-9534-244-4')
insert libro values('PB0010','19-2347-154-4')
GO

insert articolo values('PB0006','Fisica Moderna',10,4)
insert articolo values('PB0008','La Nuova Meteorolgia',10,4)
insert articolo values('PB0009','Fisica Moderna',07,2)
insert articolo values('PB0011','Ricerche Geologiche',03,3)
GO

insert autoripubblicazione values('AAABBBI456A','PB0001')
insert autoripubblicazione values('SSSMMMG456B','PB0001')
insert autoripubblicazione values('SSSVVVS456L','PB0002')
insert autoripubblicazione values('JJJMMMA456S','PB0002')
insert autoripubblicazione values('FFFMMMD345H','PB0002')
insert autoripubblicazione values('AAABBBI456A','PB0006')
insert autoripubblicazione values('AAAYYYR456N','PB0006')
insert autoripubblicazione values('SSSMMMG456B','PB0006')
insert autoripubblicazione values('SSSSSSN456D','PB0003')
insert autoripubblicazione values('YYYDDDF456Y','PB0003')
insert autoripubblicazione values('AAABBBI456A','PB0004')
insert autoripubblicazione values('SSSMMMG456B','PB0004')
insert autoripubblicazione values('KKKJJJC456F','PB0005')
insert autoripubblicazione values('FFFMMMD345H','PB0007')
insert autoripubblicazione values('YYYDDDF456Y','PB0007')
insert autoripubblicazione values('SSSSSSN456D','PB0008')
insert autoripubblicazione values('YYYDDDF456Y','PB0008')
insert autoripubblicazione values('KKKJJJC456F','PB0008')
insert autoripubblicazione values('AAABBBI456A','PB0009')
insert autoripubblicazione values('SSSMMMG456B','PB0009')
insert autoripubblicazione values('SSSVVVS456L','PB0009')
insert autoripubblicazione values('JJJMMMA456S','PB0009')
insert autoripubblicazione values('FFFMMMD345H','PB0009')
insert autoripubblicazione values('AAAYYYR456N','PB0010')
insert autoripubblicazione values('SSSSSSN456D','PB0011')
insert autoripubblicazione values('YYYDDDF456Y','PB0011')
GO

insert pubcitazione values('PB0001','PB0004')
insert pubcitazione values('PB0001','PB0007')
insert pubcitazione values('PB0001','PB0009')
insert pubcitazione values('PB0002','PB0003')
insert pubcitazione values('PB0002','PB0004')
insert pubcitazione values('PB0002','PB0007')
insert pubcitazione values('PB0002','PB0010')
insert pubcitazione values('PB0003','PB0011')
insert pubcitazione values('PB0005','PB0008')
insert pubcitazione values('PB0005','PB0011')
insert pubcitazione values('PB0006','PB0001')
insert pubcitazione values('PB0006','PB0009')
insert pubcitazione values('PB0007','PB0003')
insert pubcitazione values('PB0007','PB0004')
insert pubcitazione values('PB0007','PB0009')
insert pubcitazione values('PB0007','PB0010')
insert pubcitazione values('PB0008','PB0001')
insert pubcitazione values('PB0008','PB0011')
insert pubcitazione values('PB0009','PB0004') 
-- fine dati

-- fine file