
-- Universita degli Studi di Modena e Reggio Emilia
-- Facolta di Ingegneria
-- Dipartimento di Ingegneria Informatica
-- Laboratorio di Basi di Dati, AA 2003-2004

-- Script di generazione del database DB1101

-- INIZIO CREAZIONE STRUTTURA

USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040717' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T040717')
begin
  DROP DATABASE T040717
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040717' il proprio numero di tessera o matricola

CREATE DATABASE T040717
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040717' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T040717
GO

-- NON MODIFICARE NULLA NEL RESTO DI QUESTO FILE
-- SE NON ISTRUITO IN PROPOSITO DAL DOCENTE

CREATE TABLE [dbo].[utenti] (
	[id] [char] (10) PRIMARY KEY NOT NULL ,
	[nome] [char] (60)  NOT NULL ,
	[sex] [char] NOT NULL ,
	[datanascita] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[messaggi] (
	[id] [char] (10) PRIMARY KEY NOT NULL ,
	[oggetto] [char] (40) ,
	[testo] [varchar] (256)  NOT NULL ,
	[datainvio] [datetime] NOT NULL ,
	[argid] [char] (10) ,
	[userid] [char] (10) NOT NULL ,
	[msgid] [char] (10) 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[argomenti] (
	[id] [char] (10) PRIMARY KEY NOT NULL ,
	[titolo] [char] (40) NOT NULL ,
	[datacreazione] [datetime] NOT NULL ,
	[descrizione] [varchar] (256) ,
	[userid] [char] (10) NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[parolechiave] (
	[id] [char] (10) PRIMARY KEY NOT NULL ,
	[termine] [varchar] (40)  NOT NULL ,
	[descrizione] [varchar] (256) 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[argomento_chiave] (
	[argid] [char] (10)  NOT NULL ,
	[chiaveid] [char] (10)  NOT NULL
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[chiave_messaggio] (
	[mesgid] [char] (10)  NOT NULL ,
	[chiaveid] [char] (10)  NOT NULL
) ON [PRIMARY]
GO

-- FINE CREAZIONE STRUTTURA

-- INIZIO CARICAMENTO DATI

set nocount    on
set dateformat dmy
GO

INSERT INTO utenti VALUES ('U000000001','Mario Rossi','M','01/01/1980')
INSERT INTO utenti VALUES ('U000000002','Angela Bianchi','F','01/02/1962')
INSERT INTO utenti VALUES ('U000000003','Francesco Azzurro','M','01/03/1961')
INSERT INTO utenti VALUES ('U000000004','Valeria Verde','F','01/04/1956')
INSERT INTO utenti VALUES ('U000000005','Teresa Amaranto','F','01/05/1963')
INSERT INTO utenti VALUES ('U000000006','Sergio Marrone','M','01/06/1945')
INSERT INTO utenti VALUES ('U000000007','Giuseppe Viola','M','01/07/1974')
INSERT INTO utenti VALUES ('U000000008','Gianna Beige','F','01/08/1971')
INSERT INTO utenti VALUES ('U000000009','Giorgio Blu','M','01/09/1959')
INSERT INTO utenti VALUES ('U000000010','Serena Rosa Antico','F','01/10/1953')
GO

INSERT INTO argomenti VALUES ('ARG0000001','Titolo argomento 1','01/12/2003','Descrizione argomento 1','U000000001')
INSERT INTO argomenti VALUES ('ARG0000002','Titolo argomento 2','02/12/2003','Descrizione argomento 2','U000000001')
INSERT INTO argomenti VALUES ('ARG0000003','Titolo argomento 3','06/12/2003','Descrizione argomento 3','U000000002')
INSERT INTO argomenti VALUES ('ARG0000004','Titolo argomento 4','08/12/2003','Descrizione argomento 4','U000000002')
INSERT INTO argomenti VALUES ('ARG0000005','Titolo argomento 5','08/12/2003','Descrizione argomento 5','U000000002')
INSERT INTO argomenti VALUES ('ARG0000006','Titolo argomento 6','01/02/2004','Descrizione argomento 6','U000000003')
INSERT INTO argomenti VALUES ('ARG0000007','Titolo argomento 7','05/02/2004','Descrizione argomento 7','U000000005')
INSERT INTO argomenti VALUES ('ARG0000008','Titolo argomento 8','06/02/2004','Descrizione argomento 8','U000000007')
INSERT INTO argomenti VALUES ('ARG0000009','Titolo argomento 9','07/02/2004','Descrizione argomento 9','U000000007')
INSERT INTO argomenti VALUES ('ARG0000010','Titolo argomento 10','07/02/2004','Descrizione argomento 10','U000000010')
GO

INSERT INTO messaggi VALUES ('M000000001','titolo messaggio 1','testo messaggio M000000001','01/01/2004','ARG0000001','U000000001',NULL)
INSERT INTO messaggi VALUES ('M000000002','titolo messaggio 2','testo messaggio M000000002','02/01/2004','ARG0000001','U000000002','M000000001')
INSERT INTO messaggi VALUES ('M000000003','titolo messaggio 3','testo messaggio M000000003','02/01/2004','ARG0000001','U000000003','M000000001')
INSERT INTO messaggi VALUES ('M000000004','titolo messaggio 4','testo messaggio M000000004','03/01/2004','ARG0000001','U000000004','M000000002')
INSERT INTO messaggi VALUES ('M000000005','titolo messaggio 5','testo messaggio M000000005','01/01/2004','ARG0000002','U000000005',NULL)
INSERT INTO messaggi VALUES ('M000000006','titolo messaggio 6','testo messaggio M000000006','02/01/2004','ARG0000002','U000000006','M000000005')
INSERT INTO messaggi VALUES ('M000000007','titolo messaggio 7','testo messaggio M000000007','03/01/2004','ARG0000002','U000000007','M000000006')
INSERT INTO messaggi VALUES ('M000000008','titolo messaggio 8','testo messaggio M000000008','03/01/2004','ARG0000002','U000000008','M000000007')
INSERT INTO messaggi VALUES ('M000000009','titolo messaggio 9','testo messaggio M000000009','04/01/2004','ARG0000002','U000000009','M000000005')
INSERT INTO messaggi VALUES ('M000000010','titolo messaggio 10','testo messaggio M0000000010','01/02/2004','ARG0000005','U000000009',NULL)
INSERT INTO messaggi VALUES ('M000000011','titolo messaggio 11','testo messaggio M0000000011','02/02/2004','ARG0000006','U000000009',NULL)
INSERT INTO messaggi VALUES ('M000000012','titolo messaggio 12','testo messaggio M0000000012','03/02/2004','ARG0000007','U000000008',NULL)
INSERT INTO messaggi VALUES ('M000000013','titolo messaggio 13','testo messaggio M0000000013','04/02/2004','ARG0000008','U000000007',NULL)
INSERT INTO messaggi VALUES ('M000000014','titolo messaggio 14','testo messaggio M0000000014','05/02/2004','ARG0000009','U000000006',NULL)
INSERT INTO messaggi VALUES ('M000000015','titolo messaggio 15','testo messaggio M0000000015','06/02/2004','ARG0000005','U000000005',NULL)
INSERT INTO messaggi VALUES ('M000000016','titolo messaggio 16','testo messaggio M0000000016','07/02/2004','ARG0000006','U000000004',NULL)
INSERT INTO messaggi VALUES ('M000000017','titolo messaggio 17','testo messaggio M0000000017','08/02/2004','ARG0000007','U000000003',NULL)
INSERT INTO messaggi VALUES ('M000000018','titolo messaggio 18','testo messaggio M0000000018','09/02/2004','ARG0000008','U000000002',NULL)
INSERT INTO messaggi VALUES ('M000000019','titolo messaggio 19','testo messaggio M0000000019','01/02/2004','ARG0000009','U000000002',NULL)
INSERT INTO messaggi VALUES ('M000000020','titolo messaggio 20','testo messaggio M0000000020','01/02/2004','ARG0000005','U000000002',NULL)
INSERT INTO messaggi VALUES ('M000000021','titolo messaggio 21','testo messaggio M0000000021','01/02/2003','ARG0000005','U000000002',NULL)
GO

INSERT INTO parolechiave VALUES ('KW00000001','termine 1','descrizione termine 1')
INSERT INTO parolechiave VALUES ('KW00000002','termine 2','descrizione termine 2')
INSERT INTO parolechiave VALUES ('KW00000003','termine 3','descrizione termine 3')
INSERT INTO parolechiave VALUES ('KW00000004','termine 4','descrizione termine 4')
INSERT INTO parolechiave VALUES ('KW00000005','termine 5','descrizione termine 5')
GO

INSERT INTO argomento_chiave VALUES ('ARG0000001','KW00000001')
INSERT INTO argomento_chiave VALUES ('ARG0000001','KW00000002')
INSERT INTO argomento_chiave VALUES ('ARG0000002','KW00000003')
INSERT INTO argomento_chiave VALUES ('ARG0000004','KW00000004')
INSERT INTO argomento_chiave VALUES ('ARG0000004','KW00000005')
GO

INSERT INTO chiave_messaggio VALUES ('M000000001','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000002','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000003','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000004','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000005','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000006','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000007','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000008','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000009','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000010','KW00000002')
INSERT INTO chiave_messaggio VALUES ('M000000011','KW00000003')
INSERT INTO chiave_messaggio VALUES ('M000000012','KW00000003')
INSERT INTO chiave_messaggio VALUES ('M000000013','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000014','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000015','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000016','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000017','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000018','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000019','KW00000001')
INSERT INTO chiave_messaggio VALUES ('M000000020','KW00000001')
GO

-- FINE CARICAMENTO DATI

-- FINE FILE
