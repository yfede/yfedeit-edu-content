set nocount    on
set dateformat dmy

USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '67890' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T020706')
begin
  DROP DATABASE T020706
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '67890' il proprio numero di tessera o matricola

CREATE DATABASE T020706
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '67890' il proprio numero di tessera o matricola

USE T020706
GO

CREATE TABLE libro
(
codISBN		char(13)	NOT NULL
	CONSTRAINT UPK_codisbn PRIMARY KEY CLUSTERED,
titolo		varchar(80)	NOT NULL,
autori		varchar(80)	NOT NULL,
categoria	varchar(20)	NULL,
annopubbl	int		NULL,
edizione	varchar(20)	NULL,
pagine		int		NULL,
prezzo		money		NULL
)
GO

CREATE TABLE socio
(
codSocio	char(6)		NOT NULL,
nome		varchar(10)	NOT NULL,
cognome		varchar(20)	NOT NULL,
indirizzo	varchar(30)	NULL,
cap		char(5)		NULL 
	CHECK (cap like '[0-9][0-9][0-9][0-9][0-9]'),
telefono	varchar(20)	NOT NULL,
CONSTRAINT UPK_socio PRIMARY KEY CLUSTERED(codSocio)
)
GO

CREATE TABLE biblioteca
(
sala		varchar(6)	NOT NULL,
scaffale	varchar(4)	NOT NULL,
orario		varchar(20)	NULL,
CONSTRAINT UPK_biblioteca PRIMARY KEY CLUSTERED(sala,scaffale)
)
GO

CREATE TABLE posizione_libro
(
codISBN		char(13)	NOT NULL
	REFERENCES libro(codISBN),
sala		varchar(6)	NOT NULL,
scaffale	varchar(4)	NOT NULL,
posizione	int		NOT NULL,
CONSTRAINT UPK_poslibro PRIMARY KEY CLUSTERED(codISBN,sala,scaffale)
)
GO

CREATE TABLE prestito
(
codLibro	char(13)	NOT NULL
	REFERENCES libro(codISBN),
codSocio	char(6)		NOT NULL
	REFERENCES socio(codSocio),
dataInizio	datetime	NOT NULL,
dataFine	datetime	NULL,
CONSTRAINT UPK_prestito PRIMARY KEY CLUSTERED(codLibro,codSocio,dataInizio)
)
GO

-- inizio dati

--insert into libro values (codISBN,titolo,autori,categoria,annopubbl,edizione,pagine,prezzo)
insert into libro values ('88-371-1090-1','Progetto di basi di dati relazionali','Beneventano, Bergamaschi, Vincini','ingegneria',1999,NULL,240,NULL)
insert into libro values ('88-888-1090-1','Secrets of Silicon Valley','Greene','business',2000,NULL,NULL,NULL)
insert into libro values ('88-888-1032-2','The Busy Executive''s Database Guide','Bloss','business',2001,NULL,NULL,NULL)
insert into libro values ('00-123-4567-4','Emotional Security: A New Algorithm','Rats, Cats','psicologia',2001,NULL,NULL,NULL)
insert into libro values ('11-111-1111-1','Cooking with Computers: Surreptitious Balance Sheets','Black','business',1989,NULL,NULL,NULL)
insert into libro values ('22-222-2222-2','Silicon Valley Gastronomic Treats','Turtle','cucina',1980,NULL,NULL,NULL)
insert into libro values ('23-422-2666-4','Sushi, Anyone?','Birdie, Noddingham','cucina',1978,NULL,NULL,NULL)
insert into libro values ('28-789-4652-9','Fifty Years in Buckingham Palace Kitchens','Birdie','cucina',1977,NULL,NULL,NULL)
insert into libro values ('68-989-4552-9','You Can Combat Computer Stress!','Giantoli','business',1995,NULL,NULL,NULL)
insert into libro values ('68-922-2666-4','Is Anger the Enemy?','Plaster','psicologia',1996,NULL,NULL,NULL)

--insert into socio values (codSocio,nome,cognome,indirizzo,cap,telefono)
insert into socio values ('PLORSS','Paolo','Rossi',NULL,NULL,'021 234-5678')
insert into socio values ('GSPVRD','Giuseppe','Verdi',NULL,NULL,'021 777-5578')
insert into socio values ('PLOBNC','Paolo','Bianchi',NULL,NULL,'061 299-5600')
insert into socio values ('MCONRI','Marco','Neri',NULL,NULL,'061 234-2838')
insert into socio values ('CSRVRD','Cesare','Verdi',NULL,NULL,'061 732-9827')
insert into socio values ('SRNGLL','Serena','Gialli',NULL,NULL,'021 982-8381')
insert into socio values ('SNIBLU','Sonia','Blu',NULL,NULL,'012 983-6012')
insert into socio values ('FRNRSA','Francesca','Rosa',NULL,NULL,'051 253-9484')
insert into socio values ('TRSRST','Teresa','Rosati',NULL,NULL,'059 283-5453')
insert into socio values ('GCNVRD','Giacinto','Verdini',NULL,NULL,'012 663-5888')
insert into socio values ('PROGLL','Piero','Giallognoli',NULL,NULL,'016 984-9354')
insert into socio values ('NCLRSS','Nicola','Rossastri',NULL,NULL,'012 345-1114')
insert into socio values ('ICPGRG','Iacopo','Grigi',NULL,NULL,'016 444-5079')
insert into socio values ('GNOILL','Gino','Illitterato',NULL,NULL,'A01')

--insert into biblioteca values (sala,scaffale)
insert into biblioteca values ('A','001',NULL)
insert into biblioteca values ('A','002',NULL)
insert into biblioteca values ('B','001',NULL)
insert into biblioteca values ('B','002',NULL)
insert into biblioteca values ('B','003',NULL)
insert into biblioteca values ('C','001',NULL)

-- insert into posizione_libro values (codISBN,sala,scaffale,posizione)
insert into posizione_libro values ('88-371-1090-1','A','001',1)
insert into posizione_libro values ('88-888-1090-1','A','002',1)
insert into posizione_libro values ('88-888-1032-2','A','002',2)
insert into posizione_libro values ('00-123-4567-4','B','001',1)
insert into posizione_libro values ('11-111-1111-1','A','002',3)
insert into posizione_libro values ('22-222-2222-2','C','001',1)
insert into posizione_libro values ('23-422-2666-4','C','001',2)

-- insert into prestito values (codLibro,codSocio,dataInizio,dataFine)
insert into prestito values ('88-371-1090-1','PLORSS','02/01/02','20/01/02')
insert into prestito values ('88-371-1090-1','GSPVRD','22/01/02','25/02/02')
insert into prestito values ('88-371-1090-1','SRNGLL','15/03/02','04/04/02')
insert into prestito values ('88-888-1090-1','SRNGLL','09/05/02',NULL)
insert into prestito values ('00-123-4567-4','TRSRST','09/01/02','20/02/02')
insert into prestito values ('00-123-4567-4','MCONRI','02/03/02','20/03/02')
insert into prestito values ('00-123-4567-4','FRNRSA','21/03/02','10/05/02')
insert into prestito values ('00-123-4567-4','TRSRST','22/05/02','15/06/02')
insert into prestito values ('00-123-4567-4','PROGLL','29/06/02',NULL)
insert into prestito values ('11-111-1111-1','PROGLL','09/01/02','28/01/02')
insert into prestito values ('11-111-1111-1','ICPGRG','05/04/02','17/04/02')
insert into prestito values ('11-111-1111-1','SNIBLU','29/04/02','20/05/02')
insert into prestito values ('11-111-1111-1','NCLRSS','21/05/02','26/05/02')
insert into prestito values ('11-111-1111-1','CSRVRD','27/05/02',NULL)
insert into prestito values ('22-222-2222-2','GSPVRD','09/02/02','28/02/02')
insert into prestito values ('22-222-2222-2','PLOBNC','05/03/02','17/03/02')
insert into prestito values ('22-222-2222-2','FRNRSA','20/04/02','14/05/02')
insert into prestito values ('22-222-2222-2','TRSRST','16/05/02','18/06/02')
insert into prestito values ('22-222-2222-2','ICPGRG','29/06/02',NULL)
insert into prestito values ('23-422-2666-4','PLORSS','02/01/02',NULL)
insert into prestito values ('88-888-1032-2','GSPVRD','22/01/02','28/02/02')
insert into prestito values ('88-888-1032-2','PLORSS','07/04/02',NULL)
GO

-- fine file