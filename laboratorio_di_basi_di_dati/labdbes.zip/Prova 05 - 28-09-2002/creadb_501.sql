
USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020928' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T020928')
begin
  DROP DATABASE T020928
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020928' il proprio numero di tessera o matricola

CREATE DATABASE T020928
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020928' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T020928
GO

-- NON MODIFICARE NULLA NEL RESTO DI QUESTO FILE
-- SE NON ISTRUITO IN PROPOSITO DAL DOCENTE

CREATE TABLE authors
	(
	au_id		char(11) NOT NULL PRIMARY KEY CLUSTERED,
	au_lname	varchar(40) NOT NULL,
	au_fname 	varchar(20) NOT NULL,
	phone		char(12) NULL,
	address 	varchar(40) NULL,
	city 		varchar(20) NULL,
	state 		char(2) NULL,
	zip 		char(5) NULL
	)
GO

CREATE TABLE titles
	(
	title_id 	char(6) NOT NULL PRIMARY KEY CLUSTERED,
	title 		varchar(80) NOT NULL,
	type 		char(12) NULL,
	pub_id 		char(4) NULL,
	price 		money NULL,
	advance 	money NULL,
	ytd_sales 	int NULL,
	contract 	bit NOT NULL,
	Notes		varchar(200) NULL,
	pubdate 	smalldatetime NULL
	)
GO

CREATE TABLE editors
	(
	ed_id 		char(11) NOT NULL PRIMARY KEY CLUSTERED,
	ed_lname 	varchar(40) NOT NULL,
	ed_fname 	varchar(20) NOT NULL,
	ed_pos 		varchar(12) NULL,
	phone 		char(12) NULL,
	address 	varchar(40) NULL,
	city 		varchar(20) NULL,
	state 		char(2) NULL,
	zip 		char(5) NULL,
	ed_boss 	char(11) NULL
	)
GO

CREATE TABLE titleauthors
	(
	au_id 		char(11) NOT NULL
		REFERENCES authors(au_id),
	title_id 	char(6) NOT NULL
		REFERENCES titles(title_id),
	au_ord 		tinyint NULL,
	royaltyshare 	float NULL
	)
GO

CREATE TABLE titleditors
	(
	ed_id 		char(11) NOT NULL
		REFERENCES editors(ed_id),
	title_id 	char(6) NOT NULL
		REFERENCES titles(title_id),
	ed_ord 		tinyint NULL
	)
GO

-- FINE CREAZIONE STRUTTURA

-- INIZIO CARICAMENTO DATI

set nocount    on
set dateformat mdy
GO

INSERT INTO authors VALUES('409-56-7008','Bennet','Abraham','415 658-9932','6223 Bateman St.','Berkeley','CA','94705')
INSERT INTO authors VALUES('213-46-8915','Green','Marjorie','415 986-7020','309 63rd St. #411','Oakland','CA','94618')
INSERT INTO authors VALUES('238-95-7766','Carson','Cheryl','415 548-7723','589 Darwin Ln.','Berkeley','CA','94705')
INSERT INTO authors VALUES('998-72-3567','Ringer','Albert','801 826-0752','67 Seventh Av.','Salt Lake City','UT','84152')
INSERT INTO authors VALUES('899-46-2035','Ringer','Anne','801 826-0752','67 Seventh Av.','Salt Lake City','UT','84152')
INSERT INTO authors VALUES('722-51-5454','DeFrance','Michel','219 547-9982','3 Balding Pl.','Gary','IN','46403')
INSERT INTO authors VALUES('807-91-6654','Panteley','Sylvia','301 946-8853','1956 Arlington Pl.','Rockville','MD','20853')
INSERT INTO authors VALUES('893-72-1158','McBadden','Heather','707 448-4982','301 Putnam','Vacaville','CA','95688')
INSERT INTO authors VALUES('724-08-9931','Stringer','Dirk','415 843-2991','5420 Telegraph Av.','Oakland','CA','94609')
INSERT INTO authors VALUES('274-80-9391','Straight','Dick','415 834-2919','5420 College Av.','Oakland','CA','94609')
INSERT INTO authors VALUES('756-30-7391','Karsen','Livia','415 534-9219','5720 McAuley St.','Oakland','CA','94609')
INSERT INTO authors VALUES('724-80-9391','MacFeather','Stearns','415 354-7128','44 Upland Hts.','Oakland','CA','94612')
INSERT INTO authors VALUES('427-17-2319','Dull','Ann','415 836-7128','3410 Blonde St.','Palo Alto','CA','94301')
INSERT INTO authors VALUES('672-71-3249','Yokomoto','Akiko','415 935-4228','3 Silver Ct.','Walnut Creek','CA','94595')
INSERT INTO authors VALUES('267-41-2394','O''Leary','Michael','408 286-2428','22 Cleveland Av. #14','San Jose','CA','95128')
INSERT INTO authors VALUES('472-27-2349','Gringlesby','Burt','707 938-6445','PO Box 792','Covelo','CA','95428')
INSERT INTO authors VALUES('527-72-3246','Greene','Morningstar','615 297-2723','22 Graybar Rd.','Nashville','TN','37215')
INSERT INTO authors VALUES('172-32-1176','White','Johnson','408 496-7223','10932 Bigge Rd.','Menlo Park','CA','94025')
INSERT INTO authors VALUES('712-45-1867','del Castillo','Innes','615 996-8275','2286 Cram Pl. #86','Ann Arbor','MI','48105')
INSERT INTO authors VALUES('846-92-7186','Hunter','Sheryl','415 836-7128','3410 Blonde St.','Palo Alto','CA','94301')
INSERT INTO authors VALUES('486-29-1786','Locksley','Chastity','415 585-4620','18 Broadway Av.','San Francisco','CA','94130')
INSERT INTO authors VALUES('648-92-1872','Blotchet-Halls','Reginald','503 745-6402','55 Hill Rd','Corvallis','OR','97330')
INSERT INTO authors VALUES('341-22-1782','Smith','Meander','913 843-0462','10 Mississippi Dr.','Lawrence','KS','66044')
GO

INSERT INTO titles VALUES ('PC8888','Secrets of Silicon Valley','popular_comp','1389',40.00,8000.00,4095,1,'Muckraking reporting on the world''s largest computer hardware and software manufacturers.','06/12/1998')
INSERT INTO titles VALUES ('BU1032','The Busy Executive''s Database Guide','business','1389',29.99,5000.00,4095,1,'An overview of available database systems with emphasis on common business applications.  Illustrated.','06/12/1998')
INSERT INTO titles VALUES ('PS7777','Emotional Security: A New AlGOrithm','psychology','0736',17.99,4000.00,3336,1,'Protecting yourself and your loved ones from undue emotional stress in the modern world.  Use of computer and nutritional aids emphasized.','06/12/1998')
INSERT INTO titles VALUES ('PS3333','Prolonged Data Deprivation: Four Case Studies','psychology','0736',29.99,2000.00,4072,1,'What happens when the data runs dry?  Searching evaluations of information-shortage effects.','06/12/1998')
INSERT INTO titles VALUES ('BU1111','Cooking with Computers: Surreptitious Balance Sheets','business','1389',21.95,5000.00,3876,1,'Helpful hints on how to use your electronic resources to the best advantage.','06/09/1998')
INSERT INTO titles VALUES ('MC2222','Silicon Valley Gastronomic Treats','mod_cook','0877',29.99,0.00,2032,1, 'Favorite recipes for quick,easy,and elegant meals tried and tested by people who never have time to eat,let alone cook.','06/09/1998')
INSERT INTO titles VALUES ('TC7777','Sushi,Anyone?','trad_cook','0877',29.99,8000.00,4095,1,'Detailed instructions on improving your position in life by learning how to make authentic Japanese sushi in your spare time.','06/12/1998')
INSERT INTO titles VALUES ('TC4203','Fifty Years in Buckingham Palace Kitchens','trad_cook','0877',21.95,4000.00,15096,1,'More anecdotes from the Queen''s favorite cook describing life among English royalty.  Recipes,techniques,tender vignettes.','06/12/1998')
INSERT INTO titles VALUES ('PC1035','But Is It User Friendly?','popular_comp','1389',42.95,7000.00,8780,1,'A survey of software for the naive user,focusing on the ''friendliness'' of each.','06/30/1998')
INSERT INTO titles VALUES('BU2075','You Can Combat Computer Stress!','business','0736',12.99,10125.00,18722,1,'The latest medical and psychological techniques for living with the electronic office.  Easy-to-understand explanations.','06/30/1998')
INSERT INTO titles VALUES('PS2091','Is Anger the Enemy?','psychology','0736',21.95,2275.00,2045,1,'Carefully researched study of the effects of strong emotions on the body. Metabolic charts included.','06/15/1998')
INSERT INTO titles VALUES('PS2106','Life Without Fear','psychology','0736',17.00,6000.00,111,1,'New exercise,meditation,and nutritional techniques that can reduce the shock of daily interactions. Popular audience.  Sample menus included,exercise video available separately.','10/05/1998')
INSERT INTO titles VALUES('MC3021','The Gourmet Microwave','mod_cook','0877',12.99,15000.00,22246,1,'Traditional French GOurmet recipes adapted for modern microwave cooking.','06/18/1998')
INSERT INTO titles VALUES('TC3218','Onions,Leeks,and Garlic: Cooking Secrets of the Mediterranean','trad_cook','0877',40.95,7000.00,375,1,'Profusely illustrated in color,this makes a wonderful gift book for a cuisine-oriented friend.','10/21/1998')
INSERT INTO titles (title_id,title,pub_id,contract) VALUES('MC3026','The Psychology of Computer Cooking','0877',0)
INSERT INTO titles VALUES ('BU7832','Straight Talk About Computers','business','1389',29.99,5000.00,4095,1,'AnNOTated analysis of what computers can do for you: a no-hype guide for the critical user.','06/22/1998')
INSERT INTO titles VALUES('PS1372','Computer Phobic and Non-Phobic Individuals: Behavior Variations','psychology','0736',41.59,7000.00,375,1,'A must for the specialist,this book examines the difference between those who hate and fear computers and those who think they are swell.','10/21/1998')
INSERT INTO titles (title_id,title,type,pub_id,contract,Notes) VALUES('PC9999','Net Etiquette','popular_comp','1389',0,'A must-read for computer conferencing debutantes!.')
GO

INSERT INTO editors VALUES ( '321-55-8906','DeLongue','Martinella','project','415 843-2222','3000 6th St.','Berkeley','CA','94710','993-86-0420' )
INSERT INTO editors VALUES ( '527-72-3246','Greene','Morningstar','copy','615 297-2723','22 Graybar House Rd.','Nashville','TN','37215','826-11-9034' )
INSERT INTO editors VALUES ( '712-45-1867','del Castillo','Innes','copy','615 996-8275','2286 Cram Pl. #86','Ann Arbor','MI','48105','826-11-9034' )
INSERT INTO editors VALUES ('777-02-9831','Samuelson','Bernard','project','415 843-6990','27 Yosemite','Oakland','CA','94609','993-86-0420' )
INSERT INTO editors VALUES ('777-66-9902','Almond','Alfred','copy','312 699-4177','1010 E. Devon','ChicaGO','IL','60018','826-11-9034' )
INSERT INTO editors VALUES ('826-11-9034','Himmel','Eleanore','project','617 423-0552','97 Bleaker','Boston','MA','02210','993-86-0420' )
INSERT INTO editors VALUES ('885-23-9140','Rutherford-Hayes','Hannah','project','301 468-3909','32 Rockbill Pike','Rockbill','MD','20852','993-86-0420' )
INSERT INTO editors VALUES ('993-86-0420','McCann','Dennis','acquisition','301 468-3909','32 Rockbill Pike','Rockbill','MD','20852',NULL )
INSERT INTO editors VALUES ('943-88-7920','Kaspchek','Christof','acquisition','415 549-3909','18 Severe Rd.','Berkeley','CA','94710',NULL)
GO

INSERT INTO titleauthors VALUES('409-56-7008','BU1032',1,.60)
INSERT INTO titleauthors VALUES('486-29-1786','PS7777',1,1.00)
INSERT INTO titleauthors VALUES('486-29-1786','PC9999',1,1.00)
INSERT INTO titleauthors VALUES('712-45-1867','MC2222',1,1.00)
INSERT INTO titleauthors VALUES('172-32-1176','PS3333',1,1.00)
INSERT INTO titleauthors VALUES('213-46-8915','BU1032',2,.40)
INSERT INTO titleauthors VALUES('238-95-7766','PC1035',1,1.00)
INSERT INTO titleauthors VALUES('213-46-8915','BU2075',1,1.00)
INSERT INTO titleauthors VALUES('998-72-3567','PS2091',1,.50)
INSERT INTO titleauthors VALUES('899-46-2035','PS2091',2,.50)
INSERT INTO titleauthors VALUES('998-72-3567','PS2106',1,1.00)
INSERT INTO titleauthors VALUES('722-51-5454','MC3021',1,.75)
INSERT INTO titleauthors VALUES('899-46-2035','MC3021',2,.25)
INSERT INTO titleauthors VALUES('807-91-6654','TC3218',1,1.00)
INSERT INTO titleauthors VALUES('274-80-9391','BU7832',1,1.00)
INSERT INTO titleauthors VALUES('427-17-2319','PC8888',1,.50)
INSERT INTO titleauthors VALUES('846-92-7186','PC8888',2,.50)
INSERT INTO titleauthors VALUES('756-30-7391','PS1372',1,.75)
INSERT INTO titleauthors VALUES('724-80-9391','PS1372',2,.25)
INSERT INTO titleauthors VALUES('724-80-9391','BU1111',1,.60)
INSERT INTO titleauthors VALUES('267-41-2394','BU1111',2,.40)
INSERT INTO titleauthors VALUES('672-71-3249','TC7777',1,.40)
INSERT INTO titleauthors VALUES('267-41-2394','TC7777',2,.30)
INSERT INTO titleauthors VALUES('472-27-2349','TC7777',3,.30)
INSERT INTO titleauthors VALUES('648-92-1872','TC4203',1,1.00)
GO

INSERT INTO titleditors VALUES('826-11-9034','BU2075',2)
INSERT INTO titleditors VALUES('826-11-9034','PS2091',2)
INSERT INTO titleditors VALUES('826-11-9034','PS2106',2)
INSERT INTO titleditors VALUES('826-11-9034','PS3333',2)
INSERT INTO titleditors VALUES('826-11-9034','PS7777',2)
INSERT INTO titleditors VALUES('826-11-9034','PS1372',2)
INSERT INTO titleditors VALUES('885-23-9140','MC2222',2)
INSERT INTO titleditors VALUES('885-23-9140','MC3021',2)
INSERT INTO titleditors VALUES('885-23-9140','TC3218',2)
INSERT INTO titleditors VALUES('885-23-9140','TC4203',2)
INSERT INTO titleditors VALUES('885-23-9140','TC7777',2)
INSERT INTO titleditors VALUES('321-55-8906','BU1032',2)
INSERT INTO titleditors VALUES('321-55-8906','BU1111',2)
INSERT INTO titleditors VALUES('321-55-8906','BU7832',2)
INSERT INTO titleditors VALUES('321-55-8906','PC1035',2)
INSERT INTO titleditors VALUES('321-55-8906','PC8888',2)
INSERT INTO titleditors VALUES('321-55-8906','BU2075',3)
INSERT INTO titleditors VALUES('777-02-9831','PC1035',3)
INSERT INTO titleditors VALUES('777-02-9831','PC8888',3)
INSERT INTO titleditors VALUES('943-88-7920','BU1032',1)
INSERT INTO titleditors VALUES('943-88-7920','BU1111',1)
INSERT INTO titleditors VALUES('943-88-7920','BU2075',1)
INSERT INTO titleditors VALUES('943-88-7920','BU7832',1)
INSERT INTO titleditors VALUES('943-88-7920','PC1035',1)
INSERT INTO titleditors VALUES('943-88-7920','PC8888',1)
INSERT INTO titleditors VALUES('993-86-0420','PS1372',1)
INSERT INTO titleditors VALUES('993-86-0420','PS2091',1)
INSERT INTO titleditors VALUES('993-86-0420','PS2106',1)
INSERT INTO titleditors VALUES('993-86-0420','PS3333',1)
INSERT INTO titleditors VALUES('993-86-0420','PS7777',1)
INSERT INTO titleditors VALUES('993-86-0420','MC2222',1)
INSERT INTO titleditors VALUES('993-86-0420','MC3021',1)
INSERT INTO titleditors VALUES('993-86-0420','TC3218',1)
INSERT INTO titleditors VALUES('993-86-0420','TC4203',1)
INSERT INTO titleditors VALUES('993-86-0420','TC7777',1)
GO

-- FINE CARICAMENTO DATI

-- FINE FILE