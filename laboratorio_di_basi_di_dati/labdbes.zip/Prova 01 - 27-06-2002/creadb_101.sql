set nocount    on
set dateformat mdy

USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '12345' il proprio numero di matricola 

CREATE DATABASE T020627
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '12345' il proprio numero di matricola 

USE T020627
GO


CREATE TABLE autore
(
   au_id          varchar(11)       NOT NULL
         CONSTRAINT UPKCL_auidind PRIMARY KEY CLUSTERED,

   au_nome        varchar(40)       NOT NULL,
   phone          char(12)          NOT NULL 
         DEFAULT ('sconosciuto'),
   indirizzo      varchar(40)           NULL,
   localita       varchar(20)           NULL,
   nazione        char(2)               NULL,
   cap            char(5)               NULL 
         CHECK (cap like '[0-9][0-9][0-9][0-9][0-9]'),
   contract       bit
)
GO

CREATE TABLE editore
(
   pub_id         char(4)           NOT NULL
         CONSTRAINT UPKCL_pubind PRIMARY KEY CLUSTERED
         CHECK (pub_id in ('1389', '0736', '0877', '1622', '1756')
            OR pub_id like '99[0-9][0-9]'),
   pub_name       varchar(40)           NULL,
   indirizzo      varchar(40)           NULL,
   localita       varchar(20)           NULL,
   nazione        char(10)              NULL
         DEFAULT('USA')
)
GO

CREATE TABLE libro
(
   title_id       varchar(6)        NOT NULL
         CONSTRAINT UPKCL_titleidind PRIMARY KEY CLUSTERED,
   title          varchar(80)       NOT NULL,
   type           char(12)          NOT NULL
         DEFAULT ('da definire'),
   pub_id         char(4)               NULL
         REFERENCES editore(pub_id),
   price          money                 NULL,
   commento       varchar(200)          NULL,
   pubdate        datetime          NOT NULL
         DEFAULT (getdate())
)
GO

CREATE TABLE titoloautore
(
   au_id          varchar(11)       NOT NULL,
   title_id       varchar(6)        NOT NULL
         REFERENCES libro(title_id),
   auc            int                   NULL,
   royaltyper     int                   NULL,
   CONSTRAINT UPKCL_taind PRIMARY KEY CLUSTERED(au_id, title_id)
)
GO

CREATE TABLE vendite
(
   volume         smallint          NOT NULL,
   mese           int               NOT NULL,
   anno           int               NOT NULL,
   title_id       varchar(6)        NOT NULL
         REFERENCES libro(title_id),
   CONSTRAINT UPKCL_vendite PRIMARY KEY CLUSTERED (mese, anno, title_id)
)
GO

insert autore
   values('409-56-7008', 'Bennet Abraham', '415 658-9932',
   '6223 Bateman St.', 'Berkeley', 'CA', '94705', 1)
insert autore
   values('213-46-8915', 'Green Marjorie', '415 986-7020',
   '309 63rd St. #411', 'Oakland', 'CA', '94618', 1)
insert autore
   values('238-95-7766', 'Carson Cheryl', '415 548-7723',
   '589 Darwin Ln.', 'Berkeley', 'CA', '94705', 1)
insert autore
   values('998-72-3567', 'Ringer Albert', '801 826-0752',
   '67 Seventh Av.', 'Salt Lake City', 'UT', '84152', 1)
insert autore
   values('899-46-2035', 'Ringer Anne', '801 826-0752',
   '67 Seventh Av.', 'Salt Lake City', 'UT', '84152', 1)
insert autore
   values('722-51-5454', 'DeFrance Michel', '219 547-9982',
   '3 Balding Pl.', 'Gary', 'IN', '46403', 1)
insert autore
   values('807-91-6654', 'Panteley Sylvia', '301 946-8853',
   '1956 Arlington Pl.', 'Rockville', 'MD', '20853', 1)
insert autore
   values('893-72-1158', 'McBadden Heather',
   '707 448-4982', '301 Putnam', 'Vacaville', 'CA', '95688', 0)
insert autore
   values('724-08-9931', 'Stringer Dirk', '415 843-2991',
   '5420 Telegraph Av.', 'Oakland', 'CA', '94609', 0)
insert autore
   values('274-80-9391', 'Straight Dean', '415 834-2919',
   '5420 College Av.', 'Oakland', 'CA', '94609', 1)
insert autore
   values('756-30-7391', 'Karsen Livia', '415 534-9219',
   '5720 McAuley St.', 'Oakland', 'CA', '94609', 1)
insert autore
   values('724-80-9391', 'MacFeather Stearns', '415 354-7128',
   '44 Upland Hts.', 'Oakland', 'CA', '94612', 1)
insert autore
   values('427-17-2319', 'Dull Ann', '415 836-7128',
   '3410 Blonde St.', 'Palo Alto', 'CA', '94301', 1)
insert autore
   values('672-71-3249', 'Yokomoto Akiko', '415 935-4228',
   '3 Silver Ct.', 'Walnut Creek', 'CA', '94595', 1)
insert autore
   values('267-41-2394', 'O''Leary Michael', '408 286-2428',
   '22 Cleveland Av. #14', 'San Jose', 'CA', '95128', 1)
insert autore
   values('472-27-2349', 'Gringlesby Burt', '707 938-6445',
   'PO Box 792', 'Covelo', 'CA', '95428', 3)
insert autore
   values('527-72-3246', 'Greene Morningstar', '615 297-2723',
   '22 Graybar House Rd.', 'Nashville', 'TN', '37215', 0)
insert autore
   values('172-32-1176', 'White Johnson', '408 496-7223',
   '10932 Bigge Rd.', 'Menlo Park', 'CA', '94025', 1)
insert autore
   values('712-45-1867', 'del Castillo Innes', '615 996-8275',
   '2286 Cram Pl. #86', 'Ann Arbor', 'MI', '48105', 1)
insert autore
   values('846-92-7186', 'Hunter Sheryl', '415 836-7128',
   '3410 Blonde St.', 'Palo Alto', 'CA', '94301', 1)
insert autore
   values('486-29-1786', 'Locksley Charlene', '415 585-4620',
   '18 Broadway Av.', 'San Francisco', 'CA', '94130', 1)
insert autore
   values('648-92-1872', 'Blotchet-Halls Reginald', '503 745-6402',
   '55 Hillsdale Bl.', 'Corvallis', 'OR', '97330', 1)
insert autore
   values('341-22-1782', 'Smith Meander', '913 843-0462',
   '10 Mississippi Dr.', 'Lawrence', 'KS', '66044', 0)
GO

insert editore values('0736', 'New Moon Books', 'Boston', 'MA', 'USA')
insert editore values('0877', 'Binnet & Hardley', 'Washington', 'DC', 'USA')
insert editore values('1389', 'Algodata Infosystems', 'Berkeley', 'CA', 'USA')
insert editore values('9952', 'Scootney Books', 'New York', 'NY', 'USA')
insert editore values('1622', 'Five Lakes Publishing', 'Chicago', 'IL', 'USA')
insert editore values('1756', 'Ramona editore', 'Dallas', 'TX', 'USA')
insert editore values('9901', 'GGG&G', 'Munchen', NULL, 'Germany')
insert editore values('9999', 'Lucerne Publishing', 'Paris', NULL, 'France')
GO

insert libro values ('PC8888', 'Secrets of Silicon Valley', 'popular_comp', '1389',
$20.00, 
'Muckraking reporting on the world''s largest computer hardware and software manufacturers.',
'06/12/99')

insert libro values ('BU1032', 'The Busy Executive''s Database Guide', 'business',
'1389', $19.99, 
'An overview of available database systems with emphasis on common business applications. Illustrated.',
'07/12/99')

insert libro values ('PS7777', 'Emotional Security: A New Algorithm', 'psychology',
'0736', $7.99, 
'Protecting yourself and your loved ones from undue emotional stress in the modern world. Use of computer and nutritional aids emphasized.',
'09/12/99')

insert libro values ('PS3333', 'Prolonged Data Deprivation: Four Case Studies',
'psychology', '0736', $19.99, 
'What happens when the data runs dry?  Searching evaluations of information-shortage effects.',
'10/12/99')

insert libro values ('BU1111', 'Cooking with Computers: Surreptitious Balance Sheets',
'business', '1389', $11.95, 
'Helpful hints on how to use your electronic resources to the best advantage.',
'11/09/99')

insert libro values ('MC2222', 'Silicon Valley Gastronomic Treats', 'mod_cook', '0877',
$19.99, 
'Favorite recipes for quick, easy, and elegant meals.',
'11/09/99')

insert libro values ('TC7777', 'Sushi, Anyone?', 'trad_cook', '0877', $14.99, 
'Detailed instructions on how to make authentic Japanese sushi in your spare time.',
'02/12/00')

insert libro values ('TC4203', 'Fifty Years in Buckingham Palace Kitchens', 'trad_cook',
'0877', $11.95, 
'More anecdotes from the Queen''s favorite cook describing life among English royalty. Recipes, techniques, tender vignettes.',
'04/12/00')

insert libro values ('PC1035', 'But Is It User Friendly?', 'popular_comp', '1389',
$22.95, 
'A survey of software for the naive user, focusing on the ''friendliness'' of each.',
'04/30/00')

insert libro values('BU2075', 'You Can Combat Computer Stress!', 'business', '0736',
$2.99, 
'The latest medical and psychological techniques for living with the electronic office. Easy-to-understand explanations.',
'06/30/00')

insert libro values('PS2091', 'Is Anger the Enemy?', 'psychology', '0736', $10.95,
'Carefully researched study of the effects of strong emotions on the body. Metabolic charts included.',
'08/15/00')

insert libro values('PS2106', 'Life Without Fear', 'psychology', '0736', $7.00,
'New exercise, meditation, and nutritional techniques that can reduce the shock of daily interactions. Popular audience. Sample menus included, exercise video available separately.',
'09/05/00')

insert libro values('MC3021', 'The Gourmet Microwave', 'mod_cook', '0877', $2.99,
'Traditional French gourmet recipes adapted for modern microwave cooking.',
'10/18/00')

insert libro values('TC3218', 'Onions, Leeks, and Garlic: Cooking Secrets of the Mediterranean',
'trad_cook', '0877', $20.95, 
'Profusely illustrated in color, this makes a wonderful gift book for a cuisine-oriented friend.',
'11/21/00')

insert libro (title_id, title, pub_id) values('MC3026',
'The Psychology of Computer Cooking', '0877')

insert libro values ('BU7832', 'Straight Talk About Computers', 'business', '1389',
$19.99, 
'Annotated analysis of what computers can do for you: a no-hype guide for the critical user.',
'02/22/01')

insert libro values('PS1372', 'Computer Phobic AND Non-Phobic Individuals: Behavior Variations',
'psychology', '0877', $21.59, 
'A must for the specialist, this book examines the difference between those who hate and fear computers and those who don''t.',
'03/21/01')

insert libro (title_id, title, type, pub_id, commento) values('PC9999', 'Net Etiquette',
'popular_comp', '1389', 'A must-read for computer conferencing.')
GO

insert titoloautore values('409-56-7008', 'BU1032', 1, 60)
insert titoloautore values('486-29-1786', 'PS7777', 1, 10)
insert titoloautore values('486-29-1786', 'PC9999', 1, 10)
insert titoloautore values('712-45-1867', 'MC2222', 1, 10)
insert titoloautore values('172-32-1176', 'PS3333', 1, 10)
insert titoloautore values('213-46-8915', 'BU1032', 2, 40)
insert titoloautore values('238-95-7766', 'PC1035', 1, 10)
insert titoloautore values('213-46-8915', 'BU2075', 1, 10)
insert titoloautore values('998-72-3567', 'PS2091', 1, 50)
insert titoloautore values('899-46-2035', 'PS2091', 2, 50)
insert titoloautore values('998-72-3567', 'PS2106', 1, 10)
insert titoloautore values('722-51-5454', 'MC3021', 1, 75)
insert titoloautore values('899-46-2035', 'MC3021', 2, 25)
insert titoloautore values('807-91-6654', 'TC3218', 1, 10)
insert titoloautore values('274-80-9391', 'BU7832', 1, 10)
insert titoloautore values('427-17-2319', 'PC8888', 1, 50)
insert titoloautore values('846-92-7186', 'PC8888', 2, 50)
insert titoloautore values('756-30-7391', 'PS1372', 1, 75)
insert titoloautore values('724-80-9391', 'PS1372', 2, 25)
insert titoloautore values('724-80-9391', 'BU1111', 1, 60)
insert titoloautore values('267-41-2394', 'BU1111', 2, 40)
insert titoloautore values('672-71-3249', 'TC7777', 1, 40)
insert titoloautore values('267-41-2394', 'TC7777', 2, 30)
insert titoloautore values('472-27-2349', 'TC7777', 3, 30)
insert titoloautore values('648-92-1872', 'TC4203', 1, 10)
GO

insert vendite values(407,1,2000,'BU1032')
insert vendite values(1202,1,2000,'PS7777')
insert vendite values(1000,1,2000,'PS3333')
insert vendite values(205,1,2000,'BU1111')
insert vendite values(203,1,2000,'MC2222')
insert vendite values(207,2,2000,'BU1032')
insert vendite values(807,2,2000,'PS7777')
insert vendite values(1206,2,2000,'PS3333')
insert vendite values(1007,2,2000,'BU1111')
insert vendite values(1003,2,2000,'MC2222')
insert vendite values(11,2,2000,'TC7777')
insert vendite values(107,3,2000,'BU1032')
insert vendite values(404,3,2000,'PS7777')
insert vendite values(807,3,2000,'PS3333')
insert vendite values(1205,3,2000,'BU1111')
insert vendite values(1208,3,2000,'MC2222')
insert vendite values(200,3,2000,'TC7777')
insert vendite values(50,4,2000,'BU1032')
insert vendite values(207,4,2000,'PS7777')
insert vendite values(404,4,2000,'PS3333')
insert vendite values(801,4,2000,'BU1111')
insert vendite values(808,4,2000,'MC2222')
insert vendite values(1009,4,2000,'TC7777')
insert vendite values(13,4,2000,'TC4203')
insert vendite values(11,4,2000,'PC1035')
insert vendite values(27,5,2000,'BU1032')
insert vendite values(103,5,2000,'PS7777')
insert vendite values(206,5,2000,'PS3333')
insert vendite values(409,5,2000,'BU1111')
insert vendite values(400,5,2000,'MC2222')
insert vendite values(1204,5,2000,'TC7777')
insert vendite values(203,5,2000,'TC4203')
insert vendite values(203,5,2000,'PC1035')
insert vendite values(18,6,2000,'BU1032')
insert vendite values(50,6,2000,'PS7777')
insert vendite values(104,6,2000,'PS3333')
insert vendite values(203,6,2000,'BU1111')
insert vendite values(200,6,2000,'MC2222')
insert vendite values(804,6,2000,'TC7777')
insert vendite values(1005,6,2000,'TC4203')
insert vendite values(1002,6,2000,'PC1035')
insert vendite values(18,6,2000,'BU2075')
insert vendite values(16,7,2000,'BU1032')
insert vendite values(26,7,2000,'PS7777')
insert vendite values(54,7,2000,'PS3333')
insert vendite values(102,7,2000,'BU1111')
insert vendite values(102,7,2000,'MC2222')
insert vendite values(406,7,2000,'TC7777')
insert vendite values(1200,7,2000,'TC4203')
insert vendite values(1202,7,2000,'PC1035')
insert vendite values(204,7,2000,'BU2075')
insert vendite values(16,8,2000,'BU1032')
insert vendite values(16,8,2000,'PS7777')
insert vendite values(31,8,2000,'PS3333')
insert vendite values(57,8,2000,'BU1111')
insert vendite values(55,8,2000,'MC2222')
insert vendite values(202,8,2000,'TC7777')
insert vendite values(802,8,2000,'TC4203')
insert vendite values(802,8,2000,'PC1035')
insert vendite values(1000,8,2000,'BU2075')
insert vendite values(13,8,2000,'PS2091')
insert vendite values(14,9,2000,'BU1032')
insert vendite values(12,9,2000,'PS7777')
insert vendite values(18,9,2000,'PS3333')
insert vendite values(31,9,2000,'BU1111')
insert vendite values(26,9,2000,'MC2222')
insert vendite values(109,9,2000,'TC7777')
insert vendite values(400,9,2000,'TC4203')
insert vendite values(400,9,2000,'PC1035')
insert vendite values(1202,9,2000,'BU2075')
insert vendite values(206,9,2000,'PS2091')
insert vendite values(18,9,2000,'PS2106')
insert vendite values(0,10,2000,'BU1032')
insert vendite values(16,10,2000,'PS7777')
insert vendite values(13,10,2000,'PS3333')
insert vendite values(12,10,2000,'BU1111')
insert vendite values(13,10,2000,'MC2222')
insert vendite values(51,10,2000,'TC7777')
insert vendite values(202,10,2000,'TC4203')
insert vendite values(200,10,2000,'PC1035')
insert vendite values(804,10,2000,'BU2075')
insert vendite values(1004,10,2000,'PS2091')
insert vendite values(200,10,2000,'PS2106')
insert vendite values(17,10,2000,'MC3021')
insert vendite values(9,11,2000,'BU1032')
insert vendite values(9,11,2000,'PS7777')
insert vendite values(16,11,2000,'PS3333')
insert vendite values(10,11,2000,'BU1111')
insert vendite values(12,11,2000,'MC2222')
insert vendite values(26,11,2000,'TC7777')
insert vendite values(108,11,2000,'TC4203')
insert vendite values(101,11,2000,'PC1035')
insert vendite values(401,11,2000,'BU2075')
insert vendite values(1206,11,2000,'PS2091')
insert vendite values(1009,11,2000,'PS2106')
insert vendite values(203,11,2000,'MC3021')
insert vendite values(14,11,2000,'TC3218')
insert vendite values(7,12,2000,'BU1032')
insert vendite values(2,12,2000,'PS7777')
insert vendite values(14,12,2000,'PS3333')
insert vendite values(14,12,2000,'BU1111')
insert vendite values(16,12,2000,'MC2222')
insert vendite values(16,12,2000,'TC7777')
insert vendite values(57,12,2000,'TC4203')
insert vendite values(59,12,2000,'PC1035')
insert vendite values(202,12,2000,'BU2075')
insert vendite values(808,12,2000,'PS2091')
insert vendite values(1202,12,2000,'PS2106')
insert vendite values(1009,12,2000,'MC3021')
insert vendite values(200,12,2000,'TC3218')
insert vendite values(0,1,2001,'BU1032')
insert vendite values(9,1,2001,'PS7777')
insert vendite values(3,1,2001,'PS3333')
insert vendite values(13,1,2001,'BU1111')
insert vendite values(11,1,2001,'MC2222')
insert vendite values(17,1,2001,'TC7777')
insert vendite values(26,1,2001,'TC4203')
insert vendite values(27,1,2001,'PC1035')
insert vendite values(109,1,2001,'BU2075')
insert vendite values(403,1,2001,'PS2091')
insert vendite values(807,1,2001,'PS2106')
insert vendite values(1208,1,2001,'MC3021')
insert vendite values(1003,1,2001,'TC3218')
insert vendite values(6,2,2001,'BU1032')
insert vendite values(5,2,2001,'PS7777')
insert vendite values(7,2,2001,'PS3333')
insert vendite values(2,2,2001,'BU1111')
insert vendite values(4,2,2001,'MC2222')
insert vendite values(18,2,2001,'TC7777')
insert vendite values(19,2,2001,'TC4203')
insert vendite values(12,2,2001,'PC1035')
insert vendite values(53,2,2001,'BU2075')
insert vendite values(202,2,2001,'PS2091')
insert vendite values(406,2,2001,'PS2106')
insert vendite values(805,2,2001,'MC3021')
insert vendite values(1204,2,2001,'TC3218')
insert vendite values(19,2,2001,'BU7832')
insert vendite values(1,3,2001,'BU1032')
insert vendite values(8,3,2001,'PS7777')
insert vendite values(2,3,2001,'PS3333')
insert vendite values(1,3,2001,'BU1111')
insert vendite values(0,3,2001,'MC2222')
insert vendite values(7,3,2001,'TC7777')
insert vendite values(16,3,2001,'TC4203')
insert vendite values(18,3,2001,'PC1035')
insert vendite values(28,3,2001,'BU2075')
insert vendite values(107,3,2001,'PS2091')
insert vendite values(208,3,2001,'PS2106')
insert vendite values(406,3,2001,'MC3021')
insert vendite values(800,3,2001,'TC3218')
insert vendite values(207,3,2001,'BU7832')
insert vendite values(11,3,2001,'PS1372')
insert vendite values(9,4,2001,'BU1032')
insert vendite values(2,4,2001,'PS7777')
insert vendite values(1,4,2001,'PS3333')
insert vendite values(4,4,2001,'BU1111')
insert vendite values(5,4,2001,'MC2222')
insert vendite values(6,4,2001,'TC7777')
insert vendite values(10,4,2001,'TC4203')
insert vendite values(17,4,2001,'PC1035')
insert vendite values(12,4,2001,'BU2075')
insert vendite values(51,4,2001,'PS2091')
insert vendite values(103,4,2001,'PS2106')
insert vendite values(202,4,2001,'MC3021')
insert vendite values(404,4,2001,'TC3218')
insert vendite values(1002,4,2001,'BU7832')
insert vendite values(202,4,2001,'PS1372')
insert vendite values(7,5,2001,'BU1032')
insert vendite values(9,5,2001,'PS7777')
insert vendite values(7,5,2001,'PS3333')
insert vendite values(5,5,2001,'BU1111')
insert vendite values(1,5,2001,'MC2222')
insert vendite values(2,5,2001,'TC7777')
insert vendite values(10,5,2001,'TC4203')
insert vendite values(9,5,2001,'PC1035')
insert vendite values(13,5,2001,'BU2075')
insert vendite values(33,5,2001,'PS2091')
insert vendite values(51,5,2001,'PS2106')
insert vendite values(101,5,2001,'MC3021')
insert vendite values(202,5,2001,'TC3218')
insert vendite values(1200,5,2001,'BU7832')
insert vendite values(1009,5,2001,'PS1372')
insert vendite values(19,5,2001,'PC9999')
insert vendite values(1,6,2001,'BU1032')
insert vendite values(4,6,2001,'PS7777')
insert vendite values(1,6,2001,'PS3333')
insert vendite values(0,6,2001,'BU1111')
insert vendite values(3,6,2001,'MC2222')
insert vendite values(4,6,2001,'TC7777')
insert vendite values(6,6,2001,'TC4203')
insert vendite values(3,6,2001,'PC1035')
insert vendite values(15,6,2001,'BU2075')
insert vendite values(21,6,2001,'PS2091')
insert vendite values(32,6,2001,'PS2106')
insert vendite values(56,6,2001,'MC3021')
insert vendite values(104,6,2001,'TC3218')
insert vendite values(806,6,2001,'BU7832')
insert vendite values(1207,6,2001,'PS1372')
insert vendite values(200,6,2001,'PC9999')
insert vendite values(0,7,2001,'BU1032')
insert vendite values(9,7,2001,'PS7777')
insert vendite values(2,7,2001,'PS3333')
insert vendite values(4,7,2001,'BU1111')
insert vendite values(7,7,2001,'MC2222')
insert vendite values(4,7,2001,'TC7777')
insert vendite values(0,7,2001,'TC4203')
insert vendite values(6,7,2001,'PC1035')
insert vendite values(11,7,2001,'BU2075')
insert vendite values(16,7,2001,'PS2091')
insert vendite values(12,7,2001,'PS2106')
insert vendite values(27,7,2001,'MC3021')
insert vendite values(54,7,2001,'TC3218')
insert vendite values(401,7,2001,'BU7832')
insert vendite values(803,7,2001,'PS1372')
insert vendite values(1002,7,2001,'PC9999')
insert vendite values(6,8,2001,'BU1032')
insert vendite values(6,8,2001,'PS7777')
insert vendite values(4,8,2001,'PS3333')
insert vendite values(2,8,2001,'BU1111')
insert vendite values(4,8,2001,'MC2222')
insert vendite values(2,8,2001,'TC7777')
insert vendite values(1,8,2001,'TC4203')
insert vendite values(0,8,2001,'PC1035')
insert vendite values(0,8,2001,'BU2075')
insert vendite values(18,8,2001,'PS2091')
insert vendite values(15,8,2001,'PS2106')
insert vendite values(18,8,2001,'MC3021')
insert vendite values(25,8,2001,'TC3218')
insert vendite values(201,8,2001,'BU7832')
insert vendite values(408,8,2001,'PS1372')
insert vendite values(1208,8,2001,'PC9999')
insert vendite values(3,9,2001,'BU1032')
insert vendite values(0,9,2001,'PS7777')
insert vendite values(8,9,2001,'PS3333')
insert vendite values(1,9,2001,'BU1111')
insert vendite values(4,9,2001,'MC2222')
insert vendite values(3,9,2001,'TC7777')
insert vendite values(0,9,2001,'TC4203')
insert vendite values(6,9,2001,'PC1035')
insert vendite values(7,9,2001,'BU2075')
insert vendite values(9,9,2001,'PS2091')
insert vendite values(18,9,2001,'PS2106')
insert vendite values(19,9,2001,'MC3021')
insert vendite values(12,9,2001,'TC3218')
insert vendite values(104,9,2001,'BU7832')
insert vendite values(203,9,2001,'PS1372')
insert vendite values(800,9,2001,'PC9999')
insert vendite values(5,10,2001,'BU1032')
insert vendite values(2,10,2001,'PS7777')
insert vendite values(6,10,2001,'PS3333')
insert vendite values(8,10,2001,'BU1111')
insert vendite values(1,10,2001,'MC2222')
insert vendite values(2,10,2001,'TC7777')
insert vendite values(0,10,2001,'TC4203')
insert vendite values(4,10,2001,'PC1035')
insert vendite values(6,10,2001,'BU2075')
insert vendite values(8,10,2001,'PS2091')
insert vendite values(8,10,2001,'PS2106')
insert vendite values(15,10,2001,'MC3021')
insert vendite values(10,10,2001,'TC3218')
insert vendite values(56,10,2001,'BU7832')
insert vendite values(106,10,2001,'PS1372')
insert vendite values(405,10,2001,'PC9999')
insert vendite values(5,11,2001,'BU1032')
insert vendite values(1,11,2001,'PS7777')
insert vendite values(7,11,2001,'PS3333')
insert vendite values(5,11,2001,'BU1111')
insert vendite values(4,11,2001,'MC2222')
insert vendite values(2,11,2001,'TC7777')
insert vendite values(1,11,2001,'TC4203')
insert vendite values(8,11,2001,'PC1035')
insert vendite values(9,11,2001,'BU2075')
insert vendite values(1,11,2001,'PS2091')
insert vendite values(1,11,2001,'PS2106')
insert vendite values(10,11,2001,'MC3021')
insert vendite values(18,11,2001,'TC3218')
insert vendite values(33,11,2001,'BU7832')
insert vendite values(51,11,2001,'PS1372')
insert vendite values(205,11,2001,'PC9999')
insert vendite values(2,12,2001,'BU1032')
insert vendite values(7,12,2001,'PS7777')
insert vendite values(3,12,2001,'PS3333')
insert vendite values(5,12,2001,'BU1111')
insert vendite values(8,12,2001,'MC2222')
insert vendite values(6,12,2001,'TC7777')
insert vendite values(7,12,2001,'TC4203')
insert vendite values(9,12,2001,'PC1035')
insert vendite values(9,12,2001,'BU2075')
insert vendite values(1,12,2001,'PS2091')
insert vendite values(3,12,2001,'PS2106')
insert vendite values(4,12,2001,'MC3021')
insert vendite values(15,12,2001,'TC3218')
insert vendite values(14,12,2001,'BU7832')
insert vendite values(33,12,2001,'PS1372')
insert vendite values(108,12,2001,'PC9999')
GO

-- fine file

