
-- Universita degli Studi di Modena e Reggio Emilia
-- Facolta di Ingegneria
-- Dipartimento di Ingegneria Informatica
-- Laboratorio di Basi di Dati, AA 2003-2004

-- Script di generazione del database DB1001b

-- INIZIO CREAZIONE STRUTTURA

USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040110' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T040110')
begin
  DROP DATABASE T040110
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040110' il proprio numero di tessera o matricola

CREATE DATABASE T040110
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '040110' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T040110
GO

-- NON MODIFICARE NULLA NEL RESTO DI QUESTO FILE
-- SE NON ISTRUITO IN PROPOSITO DAL DOCENTE



CREATE TABLE [dbo].[acquisto] (
	[codcli] [char] (10)  NOT NULL ,
	[codpro] [char] (10)  NOT NULL ,
	[numunit] [int] NOT NULL ,
	[prezzounit_vend] [money] NOT NULL ,
	[data] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[cliente] (
	[codice] [char] (10)  NOT NULL ,
	[nome] [varchar] (40)  NOT NULL ,
	[cognome] [varchar] (80)  NOT NULL ,
	[puntifedelta] [float] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[dettagliofornitura] (
	[codfornitura] [char] (10)  NOT NULL ,
	[riga] [int] NOT NULL ,
	[codprod] [char] (10)  NOT NULL ,
	[quantita] [int] NOT NULL ,
	[prezzounit_acq] [money] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[fornitore] (
	[codice] [char] (10)  NOT NULL ,
	[rag_sociale] [varchar] (50)  NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[fornitura] (
	[codice] [char] (10)  NOT NULL ,
	[codfornitore] [char] (10)  NOT NULL ,
	[data] [datetime] NOT NULL 
) ON [PRIMARY]
GO

CREATE TABLE [dbo].[prodotto] (
	[codice] [char] (10)  NOT NULL ,
	[q_mag] [int] NOT NULL ,
	[q_scaff] [int] NOT NULL ,
	[storvol] [int] NOT NULL 
) ON [PRIMARY]
GO

ALTER TABLE [dbo].[cliente] ADD 
	CONSTRAINT [DF_cliente_puntifedelta] DEFAULT (0.0) FOR [puntifedelta],
	CONSTRAINT [PK_cliente] PRIMARY KEY  CLUSTERED 
	(
		[codice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[fornitore] ADD 
	CONSTRAINT [PK_fornitore] PRIMARY KEY  CLUSTERED 
	(
		[codice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[fornitura] ADD 
	CONSTRAINT [PK_fornitura] PRIMARY KEY  CLUSTERED 
	(
		[codice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[prodotto] ADD 
	CONSTRAINT [PK_prodotto] PRIMARY KEY  CLUSTERED 
	(
		[codice]
	)  ON [PRIMARY] 
GO

ALTER TABLE [dbo].[acquisto] ADD 
	CONSTRAINT [FK_acquisto_cliente] FOREIGN KEY 
	(
		[codcli]
	) REFERENCES [dbo].[cliente] (
		[codice]
	),
	CONSTRAINT [FK_acquisto_prodotto] FOREIGN KEY 
	(
		[codpro]
	) REFERENCES [dbo].[prodotto] (
		[codice]
	)
GO

ALTER TABLE [dbo].[fornitura] ADD 
	CONSTRAINT [FK_fornitura_fornitore] FOREIGN KEY 
	(
		[codfornitore]
	) REFERENCES [dbo].[fornitore] (
		[codice]
	)
GO

-- FINE CREAZIONE STRUTTURA

-- INIZIO CARICAMENTO DATI

set nocount    on
set dateformat dmy
GO

INSERT INTO fornitore VALUES ('F200300001','Drogherie Riunite SpA')
INSERT INTO fornitore VALUES ('F200300002','Alimentari SpA')
INSERT INTO fornitore VALUES ('F200300003','Prodotti per la Casa SpA')
INSERT INTO fornitore VALUES ('F200300004','Detergenti Srl')
INSERT INTO fornitore VALUES ('F200300005','Bricolage Ltd')
INSERT INTO fornitore VALUES ('F200300006','Svago e Cultura SpA')
INSERT INTO fornitore VALUES ('F200300007','Libri e Cultura SpA')
INSERT INTO fornitore VALUES ('F200300008','Editoriale Elettronica SpA')
INSERT INTO fornitore VALUES ('F200300009','Ingrosso Abbigliamento SpA')
INSERT INTO fornitore VALUES ('F200300010','Fashion Clothing Int Ltd')
GO

INSERT INTO cliente VALUES ('C200300001','Mario','Rossi',0.0)
INSERT INTO cliente VALUES ('C200300002','Giovanni','Verdi',0.0)
INSERT INTO cliente VALUES ('C200300003','Francesco','Bianco',0.0)
INSERT INTO cliente VALUES ('C200300004','Teresa','Azzurro',0.0)
INSERT INTO cliente VALUES ('C200300005','Susanna','Cremisi',0.0)
INSERT INTO cliente VALUES ('C200300006','Alice','Arcobaleno',0.0)
INSERT INTO cliente VALUES ('C200300007','Bea','Amaranto',0.0)
INSERT INTO cliente VALUES ('C200300008','Serena','Rosso',0.0)
INSERT INTO cliente VALUES ('C200300009','Alessia','Bianchi',0.0)
INSERT INTO cliente VALUES ('C200300010','Sonia','Marron',0.0)
GO

INSERT INTO prodotto VALUES ('P-casa-001',2000,40,2)
INSERT INTO prodotto VALUES ('P-casa-002',1000,20,3)
INSERT INTO prodotto VALUES ('P-casa-003',5000,100,2)
INSERT INTO prodotto VALUES ('P-casa-004',1000,110,2)
INSERT INTO prodotto VALUES ('P-casa-005',500,5,10)
INSERT INTO prodotto VALUES ('P-alim-001',10000,100,1)
INSERT INTO prodotto VALUES ('P-alim-002',5000,40,1)
INSERT INTO prodotto VALUES ('P-alim-003',2000,50,1)
INSERT INTO prodotto VALUES ('P-alim-004',2000,80,1)
INSERT INTO prodotto VALUES ('P-alim-005',2000,20,1)
INSERT INTO prodotto VALUES ('P-alim-006',2000,30,1)
INSERT INTO prodotto VALUES ('P-alim-007',2000,40,1)
INSERT INTO prodotto VALUES ('P-alim-008',2000,50,1)
INSERT INTO prodotto VALUES ('P-alim-009',2000,60,1)
INSERT INTO prodotto VALUES ('P-alim-010',2000,70,1)
INSERT INTO prodotto VALUES ('P-alim-011',15000,100,1)
INSERT INTO prodotto VALUES ('P-alim-012',7000,40,1)
INSERT INTO prodotto VALUES ('P-alim-013',4000,50,1)
INSERT INTO prodotto VALUES ('P-alim-014',6000,80,1)
INSERT INTO prodotto VALUES ('P-alim-015',8000,20,1)
INSERT INTO prodotto VALUES ('P-alim-016',3000,30,1)
INSERT INTO prodotto VALUES ('P-alim-017',6000,40,1)
INSERT INTO prodotto VALUES ('P-alim-018',9000,50,1)
INSERT INTO prodotto VALUES ('P-alim-019',2000,60,1)
INSERT INTO prodotto VALUES ('P-alim-020',9000,70,1)
INSERT INTO prodotto VALUES ('P-leis-001',2000,70,2)
INSERT INTO prodotto VALUES ('P-leis-002',2000,80,2)
INSERT INTO prodotto VALUES ('P-leis-003',2000,90,2)
INSERT INTO prodotto VALUES ('P-leis-004',2000,10,4)
INSERT INTO prodotto VALUES ('P-leis-005',2000,10,4)
INSERT INTO prodotto VALUES ('P-leis-006',2000,20,4)
INSERT INTO prodotto VALUES ('P-leis-007',1000,20,10)
INSERT INTO prodotto VALUES ('P-leis-008',1000,20,10)
INSERT INTO prodotto VALUES ('P-leis-009',1000,40,10)
INSERT INTO prodotto VALUES ('P-leis-010',500,10,20)
INSERT INTO prodotto VALUES ('P-vest-001',500,8,4)
INSERT INTO prodotto VALUES ('P-vest-002',500,7,2)
INSERT INTO prodotto VALUES ('P-vest-003',500,20,1)
INSERT INTO prodotto VALUES ('P-vest-004',500,9,4)
INSERT INTO prodotto VALUES ('P-vest-005',500,11,4)
INSERT INTO prodotto VALUES ('P-vest-006',500,15,4)
INSERT INTO prodotto VALUES ('P-vest-007',500,19,4)
INSERT INTO prodotto VALUES ('P-vest-008',500,21,4)
INSERT INTO prodotto VALUES ('P-vest-009',500,44,4)
INSERT INTO prodotto VALUES ('P-vest-010',500,10,4)
INSERT INTO prodotto VALUES ('X-premio',0,0,0)
GO

INSERT INTO acquisto VALUES ('C200300001','P-alim-001',6,2.35,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-alim-002',1,2.60,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-alim-003',2,2.50,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-alim-004',1,1.50,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-alim-001',12,2.35,'02/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-alim-002',3,2.60,'02/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-alim-003',2,2.50,'02/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-006',1,1.50,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-007',3,0.70,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-008',2,1.10,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-006',1,1.50,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-007',3,0.70,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-008',2,1.10,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-006',1,1.50,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-007',1,0.70,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-alim-008',1,1.10,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-006',2,1.50,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-007',1,0.70,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-008',5,1.10,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-006',1,1.50,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-007',1,0.70,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-008',2,1.10,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-006',2,1.50,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-007',2,0.70,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-alim-008',1,1.10,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-009',4,0.90,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-010',6,8.50,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-013',2,2.50,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-014',1,1.50,'01/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-019',1,0.90,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-012',2,1.50,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-018',2,1.10,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-alim-013',4,2.50,'03/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-019',3,0.90,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-012',2,1.50,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-018',1,1.10,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-013',2,2.50,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-009',1,0.90,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-002',2,2.60,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-008',2,1.10,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-alim-003',3,2.50,'04/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-019',5,0.90,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-012',2,1.50,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-018',1,1.10,'07/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-013',2,2.50,'07/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-009',1,0.90,'07/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-002',2,2.60,'07/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-008',2,1.10,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300007','P-alim-003',3,2.50,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-020',1,8.50,'08/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-002',2,2.60,'08/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-008',4,1.10,'17/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-003',2,2.50,'17/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-019',1,0.90,'17/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-012',2,1.50,'17/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-018',2,1.10,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-alim-013',1,2.50,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-019',3,0.90,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-012',2,1.50,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-018',1,1.10,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-013',2,2.50,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-009',1,0.90,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-002',2,2.60,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-008',2,1.10,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-003',3,2.50,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-020',1,8.50,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-002',2,2.60,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-008',4,1.10,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-003',2,2.50,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-019',1,0.90,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-012',2,1.50,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-018',2,1.10,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300009','P-alim-013',1,2.50,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-019',2,0.90,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-012',3,1.50,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-018',2,1.10,'05/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-013',3,2.50,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-010',2,8.50,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-002',1,2.60,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-008',4,1.10,'06/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-003',4,2.50,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-020',3,8.50,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-002',2,2.60,'09/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-008',3,1.10,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-003',3,2.50,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-019',2,0.90,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-012',3,1.50,'12/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-018',1,1.10,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300010','P-alim-013',1,2.50,'19/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-casa-001',1,1.50,'20/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-leis-002',1,2.60,'21/10/2003')
INSERT INTO acquisto VALUES ('C200300001','P-vest-003',1,9.95,'22/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-casa-003',1,0.99,'21/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-leis-005',1,79.95,'20/10/2003')
INSERT INTO acquisto VALUES ('C200300002','P-vest-010',1,229.95,'22/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-casa-005',1,79.95,'20/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-leis-002',1,2.60,'22/10/2003')
INSERT INTO acquisto VALUES ('C200300003','P-vest-005',1,79.95,'24/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-casa-001',1,1.50,'25/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-leis-003',1,10.50,'24/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-vest-006',1,69.95,'23/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-casa-004',1,1.50,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-leis-003',1,10.50,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300004','P-vest-004',1,59.95,'28/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-leis-003',1,10.50,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-vest-006',1,69.95,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-casa-004',1,1.50,'27/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-leis-003',1,10.50,'28/10/2003')
INSERT INTO acquisto VALUES ('C200300005','P-vest-004',1,59.95,'30/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-casa-001',1,1.51,'25/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-leis-003',1,10.50,'24/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-vest-006',1,69.95,'23/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-casa-004',1,1.50,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-leis-003',1,10.50,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300006','P-vest-004',1,59.95,'28/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-leis-003',2,10.50,'24/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-vest-006',1,69.95,'23/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-vest-004',1,59.95,'26/10/2003')
INSERT INTO acquisto VALUES ('C200300008','P-vest-009',1,39.95,'28/10/2003')
GO

INSERT INTO fornitura VALUES ('A200300001','F200300001','01/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300001',1,'P-alim-001',100,1.99)
INSERT INTO dettagliofornitura VALUES ('A200300001',2,'P-alim-002',100,2.15)
INSERT INTO dettagliofornitura VALUES ('A200300001',3,'P-alim-003',100,1.95)
INSERT INTO dettagliofornitura VALUES ('A200300001',4,'P-alim-004',100,0.99)
INSERT INTO dettagliofornitura VALUES ('A200300001',5,'P-alim-005',100,2.99)
INSERT INTO dettagliofornitura VALUES ('A200300001',6,'P-alim-006',100,0.99)
INSERT INTO dettagliofornitura VALUES ('A200300001',7,'P-alim-007',100,0.49)

INSERT INTO fornitura VALUES ('A200300002','F200300001','10/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300002',1,'P-alim-010',100,6.45)
INSERT INTO dettagliofornitura VALUES ('A200300002',2,'P-alim-009',100,0.49)
INSERT INTO dettagliofornitura VALUES ('A200300002',3,'P-alim-008',100,0.80)
INSERT INTO dettagliofornitura VALUES ('A200300002',4,'P-alim-007',100,0.48)
INSERT INTO dettagliofornitura VALUES ('A200300002',5,'P-alim-006',100,0.99)
INSERT INTO dettagliofornitura VALUES ('A200300002',6,'P-alim-005',100,3.02)
INSERT INTO dettagliofornitura VALUES ('A200300002',7,'P-alim-004',100,0.98)

INSERT INTO fornitura VALUES ('A200300003','F200300001','20/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300003',1,'P-alim-001',100,1.95)
INSERT INTO dettagliofornitura VALUES ('A200300003',2,'P-alim-002',100,2.19)
INSERT INTO dettagliofornitura VALUES ('A200300003',3,'P-alim-003',100,1.90)
INSERT INTO dettagliofornitura VALUES ('A200300003',4,'P-alim-004',100,0.95)
INSERT INTO dettagliofornitura VALUES ('A200300003',5,'P-alim-005',100,3.05)
INSERT INTO dettagliofornitura VALUES ('A200300003',6,'P-alim-006',100,1.02)

INSERT INTO fornitura VALUES ('A200300004','F200300001','30/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300004',1,'P-alim-010',100,6.47)
INSERT INTO dettagliofornitura VALUES ('A200300004',2,'P-alim-009',100,0.51)
INSERT INTO dettagliofornitura VALUES ('A200300004',3,'P-alim-008',100,0.79)
INSERT INTO dettagliofornitura VALUES ('A200300004',4,'P-alim-007',100,0.49)

INSERT INTO fornitura VALUES ('A200300005','F200300002','05/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300005',1,'P-alim-001',200,1.90)
INSERT INTO dettagliofornitura VALUES ('A200300005',2,'P-alim-002',200,2.18)
INSERT INTO dettagliofornitura VALUES ('A200300005',3,'P-alim-003',200,1.95)
INSERT INTO dettagliofornitura VALUES ('A200300005',4,'P-alim-004',200,0.95)
INSERT INTO dettagliofornitura VALUES ('A200300005',5,'P-alim-005',200,2.99)
INSERT INTO dettagliofornitura VALUES ('A200300005',6,'P-alim-006',100,1.02)
INSERT INTO dettagliofornitura VALUES ('A200300005',7,'P-alim-007',100,0.49)
INSERT INTO dettagliofornitura VALUES ('A200300005',8,'P-alim-008',100,0.79)
INSERT INTO dettagliofornitura VALUES ('A200300005',9,'P-alim-009',100,0.51)
INSERT INTO dettagliofornitura VALUES ('A200300005',10,'P-alim-010',100,6.45)

INSERT INTO fornitura VALUES ('A200300006','F200300002','25/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300006',1,'P-alim-001',200,1.88)
INSERT INTO dettagliofornitura VALUES ('A200300006',2,'P-alim-002',200,2.19)
INSERT INTO dettagliofornitura VALUES ('A200300006',3,'P-alim-003',200,1.98)
INSERT INTO dettagliofornitura VALUES ('A200300006',4,'P-alim-004',200,0.90)
INSERT INTO dettagliofornitura VALUES ('A200300006',5,'P-alim-005',200,3.07)
INSERT INTO dettagliofornitura VALUES ('A200300006',6,'P-alim-006',100,1.00)
INSERT INTO dettagliofornitura VALUES ('A200300006',7,'P-alim-007',100,0.49)
INSERT INTO dettagliofornitura VALUES ('A200300006',8,'P-alim-008',100,0.77)
INSERT INTO dettagliofornitura VALUES ('A200300006',9,'P-alim-009',100,0.53)
INSERT INTO dettagliofornitura VALUES ('A200300006',10,'P-alim-010',100,6.50)

INSERT INTO fornitura VALUES ('A200300007','F200300003','14/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300007',1,'P-alim-001',200,1.88)
INSERT INTO dettagliofornitura VALUES ('A200300007',2,'P-alim-002',200,2.19)
INSERT INTO dettagliofornitura VALUES ('A200300007',3,'P-alim-003',200,1.98)
INSERT INTO dettagliofornitura VALUES ('A200300007',4,'P-alim-004',200,0.90)
INSERT INTO dettagliofornitura VALUES ('A200300007',5,'P-alim-005',200,3.07)
INSERT INTO dettagliofornitura VALUES ('A200300007',6,'P-alim-006',100,1.00)
INSERT INTO dettagliofornitura VALUES ('A200300007',7,'P-alim-007',100,0.49)
INSERT INTO dettagliofornitura VALUES ('A200300007',8,'P-alim-008',100,0.77)
INSERT INTO dettagliofornitura VALUES ('A200300007',9,'P-alim-009',100,0.53)
INSERT INTO dettagliofornitura VALUES ('A200300007',10,'P-alim-010',100,6.50)
INSERT INTO dettagliofornitura VALUES ('A200300007',11,'P-casa-001',1000,0.85)
INSERT INTO dettagliofornitura VALUES ('A200300007',12,'P-casa-002',1000,2.30)
INSERT INTO dettagliofornitura VALUES ('A200300007',13,'P-casa-003',1000,0.38)
INSERT INTO dettagliofornitura VALUES ('A200300007',14,'P-casa-004',1000,0.88)
INSERT INTO dettagliofornitura VALUES ('A200300007',15,'P-casa-005',100,53.07)

INSERT INTO fornitura VALUES ('A200300008','F200300003','28/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300008',1,'P-casa-001',1000,0.88)
INSERT INTO dettagliofornitura VALUES ('A200300008',2,'P-casa-002',1000,2.35)
INSERT INTO dettagliofornitura VALUES ('A200300008',3,'P-casa-003',1000,0.41)
INSERT INTO dettagliofornitura VALUES ('A200300008',4,'P-casa-004',1000,0.90)
INSERT INTO dettagliofornitura VALUES ('A200300008',5,'P-casa-005',100,53.07)

INSERT INTO fornitura VALUES ('A200300009','F200300004','15/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300009',1,'P-casa-001',1000,0.87)
INSERT INTO dettagliofornitura VALUES ('A200300009',2,'P-casa-002',1000,2.33)
INSERT INTO dettagliofornitura VALUES ('A200300009',3,'P-casa-003',1000,0.43)
INSERT INTO dettagliofornitura VALUES ('A200300009',4,'P-casa-004',1000,0.92)
INSERT INTO dettagliofornitura VALUES ('A200300009',5,'P-casa-005',100,53.07)

INSERT INTO fornitura VALUES ('A200300010','F200300005','01/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300010',1,'P-leis-001',100,6.35)
INSERT INTO dettagliofornitura VALUES ('A200300010',2,'P-leis-002',100,6.95)
INSERT INTO dettagliofornitura VALUES ('A200300010',3,'P-leis-003',100,7.35)
INSERT INTO dettagliofornitura VALUES ('A200300010',4,'P-leis-004',100,32.75)
INSERT INTO dettagliofornitura VALUES ('A200300010',5,'P-leis-005',100,59.45)
INSERT INTO dettagliofornitura VALUES ('A200300010',6,'P-leis-006',100,19.05)
INSERT INTO dettagliofornitura VALUES ('A200300010',7,'P-leis-007',100,9.25)
INSERT INTO dettagliofornitura VALUES ('A200300010',8,'P-leis-008',100,136.99)
INSERT INTO dettagliofornitura VALUES ('A200300010',9,'P-leis-009',100,66.99)
INSERT INTO dettagliofornitura VALUES ('A200300010',10,'P-leis-010',100,999.35)

INSERT INTO fornitura VALUES ('A200300011','F200300006','10/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300011',1,'P-leis-001',100,6.35)
INSERT INTO dettagliofornitura VALUES ('A200300011',2,'P-leis-002',100,6.95)
INSERT INTO dettagliofornitura VALUES ('A200300011',3,'P-leis-003',100,7.35)
INSERT INTO dettagliofornitura VALUES ('A200300011',4,'P-leis-004',100,32.75)
INSERT INTO dettagliofornitura VALUES ('A200300011',5,'P-leis-005',100,59.45)
INSERT INTO dettagliofornitura VALUES ('A200300011',6,'P-leis-006',100,19.05)
INSERT INTO dettagliofornitura VALUES ('A200300011',7,'P-leis-007',100,9.25)
INSERT INTO dettagliofornitura VALUES ('A200300011',8,'P-leis-008',100,136.99)
INSERT INTO dettagliofornitura VALUES ('A200300011',9,'P-leis-009',100,66.99)
INSERT INTO dettagliofornitura VALUES ('A200300011',10,'P-leis-010',100,999.35)


INSERT INTO fornitura VALUES ('A200300012','F200300007','12/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300012',1,'P-leis-001',100,6.34)
INSERT INTO dettagliofornitura VALUES ('A200300012',2,'P-leis-002',100,6.94)
INSERT INTO dettagliofornitura VALUES ('A200300012',3,'P-leis-003',100,7.34)
INSERT INTO dettagliofornitura VALUES ('A200300012',4,'P-leis-004',100,32.74)
INSERT INTO dettagliofornitura VALUES ('A200300012',5,'P-leis-005',100,59.44)
INSERT INTO dettagliofornitura VALUES ('A200300012',6,'P-leis-006',100,19.00)
INSERT INTO dettagliofornitura VALUES ('A200300012',7,'P-leis-007',100,9.24)
INSERT INTO dettagliofornitura VALUES ('A200300012',8,'P-leis-008',100,136.99)
INSERT INTO dettagliofornitura VALUES ('A200300012',9,'P-leis-009',100,64.99)
INSERT INTO dettagliofornitura VALUES ('A200300012',10,'P-leis-010',100,995.00)


INSERT INTO fornitura VALUES ('A200300013','F200300008','22/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300013',1,'P-leis-001',100,6.40)
INSERT INTO dettagliofornitura VALUES ('A200300013',2,'P-leis-002',100,7.05)
INSERT INTO dettagliofornitura VALUES ('A200300013',3,'P-leis-003',100,7.00)
INSERT INTO dettagliofornitura VALUES ('A200300013',4,'P-leis-004',100,33.05)
INSERT INTO dettagliofornitura VALUES ('A200300013',5,'P-leis-005',100,59.99)
INSERT INTO dettagliofornitura VALUES ('A200300013',6,'P-leis-006',100,19.00)
INSERT INTO dettagliofornitura VALUES ('A200300013',7,'P-leis-007',100,9.20)
INSERT INTO dettagliofornitura VALUES ('A200300013',8,'P-leis-008',100,136.95)
INSERT INTO dettagliofornitura VALUES ('A200300013',9,'P-leis-009',100,65.40)
INSERT INTO dettagliofornitura VALUES ('A200300013',10,'P-leis-010',100,995.00)

INSERT INTO fornitura VALUES ('A200300014','F200300009','02/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300014',1,'P-vest-001',100,38.40)
INSERT INTO dettagliofornitura VALUES ('A200300014',2,'P-vest-002',100,10.40)
INSERT INTO dettagliofornitura VALUES ('A200300014',3,'P-vest-003',100,4.90)
INSERT INTO dettagliofornitura VALUES ('A200300014',4,'P-vest-004',100,41.20)
INSERT INTO dettagliofornitura VALUES ('A200300014',5,'P-vest-005',100,50.00)
INSERT INTO dettagliofornitura VALUES ('A200300014',6,'P-vest-006',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300014',7,'P-vest-007',100,35.25)
INSERT INTO dettagliofornitura VALUES ('A200300014',8,'P-vest-008',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300014',9,'P-vest-009',100,19.90)
INSERT INTO dettagliofornitura VALUES ('A200300014',10,'P-vest-010',100,209.95)


INSERT INTO fornitura VALUES ('A200300015','F200300009','20/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300015',1,'P-vest-001',100,38.30)
INSERT INTO dettagliofornitura VALUES ('A200300015',2,'P-vest-002',100,10.40)
INSERT INTO dettagliofornitura VALUES ('A200300015',3,'P-vest-003',100,4.90)
INSERT INTO dettagliofornitura VALUES ('A200300015',4,'P-vest-004',100,41.20)
INSERT INTO dettagliofornitura VALUES ('A200300015',5,'P-vest-005',100,50.00)
INSERT INTO dettagliofornitura VALUES ('A200300015',6,'P-vest-006',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300015',7,'P-vest-007',100,35.25)
INSERT INTO dettagliofornitura VALUES ('A200300015',8,'P-vest-008',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300015',9,'P-vest-009',100,19.90)
INSERT INTO dettagliofornitura VALUES ('A200300015',10,'P-vest-010',100,209.95)


INSERT INTO fornitura VALUES ('A200300016','F200300010','02/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300016',1,'P-vest-001',100,38.50)
INSERT INTO dettagliofornitura VALUES ('A200300016',2,'P-vest-002',100,10.40)
INSERT INTO dettagliofornitura VALUES ('A200300016',3,'P-vest-003',100,4.95)
INSERT INTO dettagliofornitura VALUES ('A200300016',4,'P-vest-004',100,41.30)
INSERT INTO dettagliofornitura VALUES ('A200300016',5,'P-vest-005',100,50.00)
INSERT INTO dettagliofornitura VALUES ('A200300016',6,'P-vest-006',100,39.00)
INSERT INTO dettagliofornitura VALUES ('A200300016',7,'P-vest-007',100,35.25)
INSERT INTO dettagliofornitura VALUES ('A200300016',8,'P-vest-008',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300016',9,'P-vest-009',100,19.90)
INSERT INTO dettagliofornitura VALUES ('A200300016',10,'P-vest-010',100,209.95)


INSERT INTO fornitura VALUES ('A200300017','F200300010','28/10/2003')
INSERT INTO dettagliofornitura VALUES ('A200300017',1,'P-vest-001',100,38.40)
INSERT INTO dettagliofornitura VALUES ('A200300017',2,'P-vest-002',100,10.40)
INSERT INTO dettagliofornitura VALUES ('A200300017',3,'P-vest-003',100,4.95)
INSERT INTO dettagliofornitura VALUES ('A200300017',4,'P-vest-004',100,41.30)
INSERT INTO dettagliofornitura VALUES ('A200300017',5,'P-vest-005',100,50.00)
INSERT INTO dettagliofornitura VALUES ('A200300017',6,'P-vest-006',100,39.99)
INSERT INTO dettagliofornitura VALUES ('A200300017',7,'P-vest-007',100,35.25)
INSERT INTO dettagliofornitura VALUES ('A200300017',8,'P-vest-008',100,39.00)
INSERT INTO dettagliofornitura VALUES ('A200300017',9,'P-vest-009',100,19.90)
INSERT INTO dettagliofornitura VALUES ('A200300017',10,'P-vest-010',100,209.95)
GO

-- FINE CARICAMENTO DATI

-- FINE FILE
