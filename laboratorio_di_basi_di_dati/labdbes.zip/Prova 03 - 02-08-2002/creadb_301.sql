
USE master
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020802' il proprio numero di tessera o matricola 
-- (due sostituzioni)

if exists (select * from sysdatabases where name='T020802')
begin
  DROP DATABASE T020802
end
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020802' il proprio numero di tessera o matricola

CREATE DATABASE T020802
GO

-- nel comando che segue cambiare il nome del database sostituendo 
-- a '020802' il proprio numero di tessera o matricola
-- Questa e' l'ultima modifica necessaria per usare questo file di 
-- comandi SQL

USE T020802
GO

CREATE TABLE musicista  -- singolo attore umano
(
cod_musicista	char(10)	NOT NULL
	CONSTRAINT UPK_cod_musicista PRIMARY KEY CLUSTERED,
nome		varchar(40)	NOT NULL,
data_nascita	datetime	NULL,
data_morte	datetime	NULL,
commento	varchar(240)	NULL
)
GO

CREATE TABLE autore  -- autore (di un pezzo o una opera)
(
cod_autore	char(10)	NOT NULL
	CONSTRAINT UPK_cod_autore PRIMARY KEY CLUSTERED
	REFERENCES musicista(cod_musicista),
commento	varchar(80)	NULL
)
GO

CREATE TABLE solista  -- singolo esecutore o prima voce
(
cod_solo	char(10)	NOT NULL
	CONSTRAINT UPK_cod_solista PRIMARY KEY CLUSTERED
	REFERENCES musicista(cod_musicista),
strumento	varchar(40)	NOT NULL,
commento	varchar(80)	NULL
)
GO

CREATE TABLE ensemble  -- orchestra o gruppo musicale
(
cod_ensemble	char(10)	NOT NULL
	CONSTRAINT UPK_cod_ensemble PRIMARY KEY CLUSTERED,
nome		varchar(40)	NOT NULL,
commento	varchar(240)	NULL
)
GO

CREATE TABLE opera  -- composizione di piu' pezzi a formare un'opera
(
cod_opera	char(10)	NOT NULL
	CONSTRAINT UPK_cod_opera PRIMARY KEY CLUSTERED,
cod_autore	char(10)	NULL
	REFERENCES autore(cod_autore),
cod_ensemble	char(10)	NULL
	REFERENCES ensemble(cod_ensemble),
cod_solo	char(10)	NULL
	REFERENCES solista(cod_solo),
titolo		varchar(40)	NOT NULL,
data_realizz	datetime	NULL,
genere		varchar(20)	NULL, -- classica, pop, rock, jazz, folk, opera, ...
subgenere	varchar(20)	NULL, -- punk-rock, fusion-jazz, barocco-classica, ...
commento	varchar(240)	NULL
)
GO


-- inizio dati

set nocount    on
set dateformat dmy
GO

--insert into musicista values (cod_musicista,nome,data_nascita,data_morte,commento)
insert into musicista values ('CM000','Vari',NULL,NULL,NULL)
insert into musicista values ('CM001','Bruno',NULL,NULL,'DJ Cafe del Mar')
insert into musicista values ('CM002','David Gilmour',NULL,NULL,NULL)
insert into musicista values ('CM003','Nick Mason',NULL,NULL,NULL)
insert into musicista values ('CM004','Richard Wright',NULL,NULL,NULL)
insert into musicista values ('CM005','Roger Waters',NULL,NULL,NULL)
insert into musicista values ('CM006','Francesco Guccini',NULL,NULL,NULL)
insert into musicista values ('CM007','Caetano Veloso',NULL,NULL,NULL)
insert into musicista values ('CM008','India Arie',NULL,NULL,NULL)
insert into musicista values ('CM009','Macy Gray',NULL,NULL,NULL)
insert into musicista values ('CM010','Salvatore Accardo',NULL,NULL,NULL)
insert into musicista values ('CM011','Niccolo Paganini','01/01/1782','01/01/1840',NULL)
insert into musicista values ('CM012','Ludovico Einaudi',NULL,NULL,NULL)
insert into musicista values ('CM013','Brian Eno',NULL,NULL,NULL)
GO

--insert into autore values (cod_autore,commento)
insert into autore values ('CM000',NULL)
insert into autore values ('CM001',NULL)
insert into autore values ('CM005',NULL)
insert into autore values ('CM006',NULL)
insert into autore values ('CM007',NULL)
insert into autore values ('CM008',NULL)
insert into autore values ('CM009',NULL)
insert into autore values ('CM011',NULL)
insert into autore values ('CM012',NULL)
insert into autore values ('CM013',NULL)
GO

--insert into solista values (cod_solo,strumento,commento)
insert into solista values ('CM001','DJ',NULL)
insert into solista values ('CM002','chitarra',NULL)
insert into solista values ('CM003','percussioni',NULL)
insert into solista values ('CM004','tastiere',NULL)
insert into solista values ('CM005','basso',NULL)
insert into solista values ('CM006','chitarra',NULL)
insert into solista values ('CM007','chitarra',NULL)
insert into solista values ('CM008','voce',NULL)
insert into solista values ('CM009','voce',NULL)
insert into solista values ('CM010','violino',NULL)
insert into solista values ('CM012','pianoforte',NULL)
GO

--insert into ensemble values (cod_ensemble,nome,commento)
insert into ensemble values ('CE000','Vari esecutori',NULL)
insert into ensemble values ('CE001','Pink Floyd',NULL)
insert into ensemble values ('CE002','R.E.M.',NULL)
GO

--insert into opera values (cod_opera,cod_autore,cod_ensemble,cod_solo,titolo,data_realizz,genere,subgenere,commento)
insert into opera values ('CO001','CM005','CE001',NULL,'The dark side of the moon','31/01/1973','rock',NULL,NULL)
insert into opera values ('CO002','CM006',NULL,'CM006','Fra la via Emilia e il west','15/09/2000','musica italiana','live',NULL)
insert into opera values ('CO003','CM006',NULL,'CM006','via Paolo Fabbri 43','30/06/1976','musica italiana',NULL,NULL)
insert into opera values ('CO004','CM008',NULL,'CM008','Acoustic soul','01/06/2001','soul',NULL,NULL)
insert into opera values ('CO005','CM007',NULL,'CM007','Estrangeiro',NULL,'brazil',NULL,NULL)
insert into opera values ('CO006','CM009',NULL,'CM009','On how life is',NULL,'soul',NULL,NULL)
insert into opera values ('CO007','CM000','CE000','CM001','Cafe del Mar - Volumen nueve','01/03/2002','TBD','chill-out',NULL)
insert into opera values ('CO008','CM011',NULL,'CM010','24 capricci, Op. 1','19/02/2002','classica',NULL,NULL)
insert into opera values ('CO009','CM012',NULL,'CM012','Eden Roc',NULL,'TBD',NULL,NULL)
insert into opera values ('CO010','CM000','CE000','CM001','Cafe del Mar - Volumen siete','01/03/2000','TBD','chill-out',NULL)
insert into opera values ('CO011','CM000','CE002',NULL,'Up','31/01/1998','rock',NULL,NULL)
insert into opera values ('CO012','CM013',NULL,NULL,'Music for airports','31/01/1978','ambient',NULL,NULL)
GO

-- fine file